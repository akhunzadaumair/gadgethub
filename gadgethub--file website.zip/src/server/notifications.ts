import { Order, NotificationDelivery, OrderNotifications } from '../types';

export const STORE_OWNER_EMAIL = 'akhunzadaumair27@gmail.com';
export const STORE_OWNER_WHATSAPP = '+923293778337';

export function getNotificationServiceStatus() {
  const resendApiKey = process.env.RESEND_API_KEY;
  const whatsappToken = process.env.WHATSAPP_ACCESS_TOKEN;
  const whatsappPhoneId = process.env.WHATSAPP_PHONE_NUMBER_ID;

  return {
    email: {
      provider: 'Resend',
      configured: Boolean(resendApiKey && resendApiKey.trim() !== ''),
      recipient: process.env.ORDER_NOTIFICATION_EMAIL || STORE_OWNER_EMAIL,
      from: process.env.EMAIL_FROM || 'Gadgethub Orders <onboarding@resend.dev>',
      help: resendApiKey ? 'Resend API key configured' : 'Awaiting RESEND_API_KEY in .env',
    },
    whatsapp: {
      provider: 'WhatsApp Business Cloud API',
      configured: Boolean(
        whatsappToken &&
        whatsappToken.trim() !== '' &&
        whatsappPhoneId &&
        whatsappPhoneId.trim() !== ''
      ),
      recipient: process.env.WHATSAPP_RECIPIENT_NUMBER || STORE_OWNER_WHATSAPP,
      phoneNumberId: whatsappPhoneId ? `${whatsappPhoneId.slice(0, 4)}...${whatsappPhoneId.slice(-4)}` : 'Not set',
      templateName: process.env.WHATSAPP_TEMPLATE_NAME || 'Default Formatted Text Message',
      templateLanguage: process.env.WHATSAPP_TEMPLATE_LANGUAGE || 'en_US',
      help: (whatsappToken && whatsappPhoneId)
        ? 'Meta WhatsApp Cloud API credentials configured'
        : 'Awaiting WHATSAPP_ACCESS_TOKEN and WHATSAPP_PHONE_NUMBER_ID in .env',
    },
  };
}

/**
 * Sends a rich, branded email notification to the store owner via Resend
 */
export async function sendOrderEmailNotification(order: Order): Promise<NotificationDelivery> {
  const recipient = (process.env.ORDER_NOTIFICATION_EMAIL || STORE_OWNER_EMAIL).trim();
  const apiKey = (process.env.RESEND_API_KEY || '').trim();
  const fromEmail = (process.env.EMAIL_FROM || 'Gadgethub Orders <onboarding@resend.dev>').trim();

  if (!apiKey) {
    console.warn(`[Notifications] RESEND_API_KEY not configured. Email notification skipped for order ${order.id}.`);
    return {
      status: 'not_configured',
      recipient,
      provider: 'Resend',
      error: 'RESEND_API_KEY is not configured in server environment or .env file.',
    };
  }

  const orderDateFormatted = new Date(order.date).toLocaleString('en-PK', {
    timeZone: 'Asia/Karachi',
    dateStyle: 'full',
    timeStyle: 'short',
  });

  const itemsHtml = order.items
    .map(
      (item) => `
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="padding: 12px 8px; font-family: sans-serif; font-size: 14px; color: #1e293b;">
          <strong>${item.product.title}</strong><br/>
          <span style="font-size: 12px; color: #64748b;">SKU: ${item.product.sku || 'N/A'}${item.selectedColor ? ` · Color: ${item.selectedColor}` : ''}</span>
        </td>
        <td style="padding: 12px 8px; font-family: monospace; font-size: 14px; color: #334155; text-align: center;">
          ${item.quantity}
        </td>
        <td style="padding: 12px 8px; font-family: monospace; font-size: 14px; color: #334155; text-align: right;">
          PKR ${item.product.price.toLocaleString()}
        </td>
        <td style="padding: 12px 8px; font-family: monospace; font-size: 14px; color: #0f172a; font-weight: bold; text-align: right;">
          PKR ${(item.product.price * item.quantity).toLocaleString()}
        </td>
      </tr>
    `
    )
    .join('');

  const itemsText = order.items
    .map(
      (item) =>
        `- ${item.product.title} (Qty: ${item.quantity}) @ PKR ${item.product.price.toLocaleString()} = PKR ${(item.product.price * item.quantity).toLocaleString()}`
    )
    .join('\n');

  const htmlBody = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8"/>
      <title>New Order Alert: ${order.id}</title>
    </head>
    <body style="margin: 0; padding: 24px; background-color: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
      <div style="max-width: 650px; margin: 0 auto; background: #ffffff; border-radius: 12px; border: 1px solid #e2e8f0; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
        
        <!-- Header -->
        <div style="background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); padding: 28px; text-align: left; color: #ffffff;">
          <div style="font-size: 24px; font-weight: 800; letter-spacing: -0.5px; color: #f59e0b; display: flex; align-items: center; gap: 8px;">
            ⚡ GADGETHUB <span style="font-size: 13px; font-weight: 600; color: #94a3b8; background: #334155; padding: 3px 8px; border-radius: 4px; text-transform: uppercase;">New Order Placed</span>
          </div>
          <h2 style="margin: 12px 0 4px 0; font-size: 20px; font-weight: 700; color: #ffffff;">
            Order ID: ${order.id}
          </h2>
          <p style="margin: 0; font-size: 13px; color: #cbd5e1;">
            Placed on ${orderDateFormatted}
          </p>
        </div>

        <!-- Body Content -->
        <div style="padding: 24px;">

          <!-- Customer & Shipping Summary Card -->
          <div style="background: #f1f5f9; border-radius: 8px; padding: 16px; margin-bottom: 24px;">
            <h3 style="margin-top: 0; margin-bottom: 12px; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px; color: #475569;">
              👤 Customer & Delivery Information
            </h3>
            <table style="width: 100%; font-size: 13px; line-height: 1.6; color: #1e293b;">
              <tr>
                <td style="width: 140px; color: #64748b; font-weight: 600;">Full Name:</td>
                <td style="font-weight: 600;">${order.customer.fullName}</td>
              </tr>
              <tr>
                <td style="color: #64748b; font-weight: 600;">Email:</td>
                <td><a href="mailto:${order.customer.email}" style="color: #2563eb; text-decoration: none;">${order.customer.email}</a></td>
              </tr>
              <tr>
                <td style="color: #64748b; font-weight: 600;">Phone:</td>
                <td style="font-weight: 600;"><a href="tel:${order.customer.phone}" style="color: #0f172a; text-decoration: none;">${order.customer.phone}</a></td>
              </tr>
              <tr>
                <td style="color: #64748b; font-weight: 600;">Shipping Address:</td>
                <td>${order.customer.address}, ${order.customer.city}, ${order.customer.province} ${order.customer.postalCode || ''}</td>
              </tr>
              ${
                order.customer.orderNotes
                  ? `<tr>
                      <td style="color: #64748b; font-weight: 600;">Order Notes:</td>
                      <td style="color: #b45309; font-style: italic;">${order.customer.orderNotes}</td>
                    </tr>`
                  : ''
              }
              <tr>
                <td style="color: #64748b; font-weight: 600;">Tracking Number:</td>
                <td style="font-family: monospace; font-weight: bold; color: #0284c7;">${order.trackingNumber} (${order.courierName})</td>
              </tr>
            </table>
          </div>

          <!-- Items Table -->
          <h3 style="margin-top: 0; margin-bottom: 12px; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px; color: #475569;">
            📦 Ordered Items (${order.items.length})
          </h3>
          <table style="width: 100%; border-collapse: collapse; margin-bottom: 24px;">
            <thead>
              <tr style="background: #f8fafc; border-bottom: 2px solid #e2e8f0; text-align: left; font-size: 12px; color: #64748b; text-transform: uppercase;">
                <th style="padding: 10px 8px;">Product</th>
                <th style="padding: 10px 8px; text-align: center;">Qty</th>
                <th style="padding: 10px 8px; text-align: right;">Unit Price</th>
                <th style="padding: 10px 8px; text-align: right;">Subtotal</th>
              </tr>
            </thead>
            <tbody>
              ${itemsHtml}
            </tbody>
          </table>

          <!-- Financial Breakdown -->
          <div style="margin-left: auto; width: 280px; margin-bottom: 24px;">
            <table style="width: 100%; font-size: 13px; line-height: 1.8; color: #334155;">
              <tr>
                <td>Subtotal:</td>
                <td style="text-align: right; font-family: monospace;">PKR ${order.subtotal.toLocaleString()}</td>
              </tr>
              <tr>
                <td>Shipping Fee:</td>
                <td style="text-align: right; font-family: monospace;">${order.shippingFee === 0 ? 'FREE' : `PKR ${order.shippingFee.toLocaleString()}`}</td>
              </tr>
              ${
                order.discount > 0
                  ? `<tr>
                      <td style="color: #16a34a;">Voucher Discount:</td>
                      <td style="text-align: right; font-family: monospace; color: #16a34a;">- PKR ${order.discount.toLocaleString()}</td>
                    </tr>`
                  : ''
              }
              <tr style="border-top: 2px solid #0f172a; font-weight: bold; font-size: 16px; color: #0f172a;">
                <td style="padding-top: 8px;">Grand Total:</td>
                <td style="padding-top: 8px; text-align: right; font-family: monospace; color: #0f172a;">PKR ${order.total.toLocaleString()}</td>
              </tr>
            </table>
          </div>

          <!-- Payment and Status Alert -->
          <div style="background: #ecfdf5; border: 1px solid #a7f3d0; border-radius: 8px; padding: 14px; font-size: 13px; color: #065f46;">
            <strong>Payment Method:</strong> ${order.paymentMethod.toUpperCase()} · 
            <strong>Payment Status:</strong> ${order.paymentMethod === 'cod' ? 'Cash on Delivery (Pending Collection)' : 'Payment Initiated'} · 
            <strong>Order Status:</strong> ${order.status}
          </div>
        </div>

        <!-- Footer -->
        <div style="background: #f8fafc; padding: 16px 24px; border-top: 1px solid #e2e8f0; font-size: 11px; color: #94a3b8; text-align: center;">
          Sent securely by Gadgethub E-Commerce Server to Store Owner (${recipient}).<br/>
          Order saved in Supabase PostgreSQL database.
        </div>
      </div>
    </body>
    </html>
  `;

  const plainText = `
GADGETHUB NEW ORDER ALERT
=========================
Order ID: ${order.id}
Date: ${orderDateFormatted}
Status: ${order.status}
Payment Method: ${order.paymentMethod.toUpperCase()}

CUSTOMER DETAILS:
Name: ${order.customer.fullName}
Email: ${order.customer.email}
Phone: ${order.customer.phone}
Address: ${order.customer.address}, ${order.customer.city}, ${order.customer.province} ${order.customer.postalCode || ''}
Tracking: ${order.trackingNumber} (${order.courierName})
${order.customer.orderNotes ? `Notes: ${order.customer.orderNotes}\n` : ''}
ITEMS:
${itemsText}

FINANCIALS:
Subtotal: PKR ${order.subtotal.toLocaleString()}
Shipping: ${order.shippingFee === 0 ? 'FREE' : `PKR ${order.shippingFee.toLocaleString()}`}
Discount: PKR ${order.discount.toLocaleString()}
TOTAL: PKR ${order.total.toLocaleString()}
  `.trim();

  try {
    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: fromEmail,
        to: [recipient],
        subject: `🛒 New Gadgethub Order: ${order.id} - PKR ${order.total.toLocaleString()}`,
        html: htmlBody,
        text: plainText,
      }),
    });

    const data = await res.json();

    if (res.ok && data?.id) {
      console.log(`[Notifications] Email successfully delivered via Resend. Message ID: ${data.id}`);
      return {
        status: 'sent',
        recipient,
        provider: 'Resend',
        sentAt: new Date().toISOString(),
        messageId: data.id,
      };
    } else {
      const errMsg = data?.message || data?.error || `HTTP ${res.status}: ${res.statusText}`;
      console.error(`[Notifications] Resend email delivery failed:`, errMsg);
      return {
        status: 'failed',
        recipient,
        provider: 'Resend',
        error: errMsg,
      };
    }
  } catch (err: any) {
    console.error(`[Notifications] Network error sending email via Resend:`, err);
    return {
      status: 'failed',
      recipient,
      provider: 'Resend',
      error: err?.message || 'Network error connecting to Resend API',
    };
  }
}

/**
 * Sends an official WhatsApp notification to the store owner via Meta WhatsApp Business Cloud API
 */
export async function sendOrderWhatsAppNotification(order: Order): Promise<NotificationDelivery> {
  const recipient = (process.env.WHATSAPP_RECIPIENT_NUMBER || STORE_OWNER_WHATSAPP).trim();
  const accessToken = (process.env.WHATSAPP_ACCESS_TOKEN || '').trim();
  const phoneId = (process.env.WHATSAPP_PHONE_NUMBER_ID || '').trim();
  const templateName = (process.env.WHATSAPP_TEMPLATE_NAME || '').trim();
  const templateLang = (process.env.WHATSAPP_TEMPLATE_LANGUAGE || 'en_US').trim();

  if (!accessToken || !phoneId) {
    console.warn(`[Notifications] WhatsApp Cloud API credentials not configured. WhatsApp alert skipped for order ${order.id}.`);
    return {
      status: 'not_configured',
      recipient,
      provider: 'WhatsApp Business Cloud API',
      error: 'WHATSAPP_ACCESS_TOKEN or WHATSAPP_PHONE_NUMBER_ID is not configured in server environment or .env file.',
    };
  }

  // Format recipient phone number for WhatsApp Cloud API (digits only, e.g. 923293778337)
  const cleanPhone = recipient.replace(/[^\d]/g, '');

  const itemsSummary = order.items
    .map((item) => `${item.product.title} (x${item.quantity})`)
    .join(', ');

  const orderDateFormatted = new Date(order.date).toLocaleDateString('en-PK', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  let requestBody: any;

  if (templateName) {
    // Official WhatsApp Business Approved Template mode
    requestBody = {
      messaging_product: 'whatsapp',
      recipient_type: 'individual',
      to: cleanPhone,
      type: 'template',
      template: {
        name: templateName,
        language: {
          code: templateLang,
        },
        components: [
          {
            type: 'body',
            parameters: [
              { type: 'text', text: order.id },
              { type: 'text', text: order.customer.fullName },
              { type: 'text', text: itemsSummary.slice(0, 100) },
              { type: 'text', text: `PKR ${order.total.toLocaleString()}` },
              { type: 'text', text: `${order.customer.address}, ${order.customer.city}` },
              { type: 'text', text: `${order.paymentMethod.toUpperCase()} (${order.status})` },
            ],
          },
        ],
      },
    };
  } else {
    // WhatsApp Cloud API Formatted Text Message mode
    const textMessage = [
      `🛒 *NEW GADGETHUB ORDER ALERT*`,
      `━━━━━━━━━━━━━━━━━━`,
      `📦 *Order ID:* ${order.id}`,
      `📅 *Date:* ${orderDateFormatted}`,
      ``,
      `👤 *Customer:* ${order.customer.fullName}`,
      `📞 *Phone:* ${order.customer.phone}`,
      `📍 *Address:* ${order.customer.address}, ${order.customer.city}, ${order.customer.province}`,
      ``,
      `🛍️ *Items (${order.items.length}):*`,
      ...order.items.map(
        (i) => `• ${i.product.title} (x${i.quantity}) - PKR ${(i.product.price * i.quantity).toLocaleString()}`
      ),
      ``,
      `💰 *Total Amount:* *PKR ${order.total.toLocaleString()}*`,
      `💳 *Payment:* ${order.paymentMethod.toUpperCase()} (${order.status})`,
      `🚚 *Courier:* ${order.courierName}`,
      `🔖 *Tracking #:* ${order.trackingNumber}`,
      `━━━━━━━━━━━━━━━━━━`,
      `_Saved to Supabase database._`,
    ].join('\n');

    requestBody = {
      messaging_product: 'whatsapp',
      recipient_type: 'individual',
      to: cleanPhone,
      type: 'text',
      text: {
        preview_url: false,
        body: textMessage,
      },
    };
  }

  try {
    const res = await fetch(`https://graph.facebook.com/v21.0/${phoneId}/messages`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestBody),
    });

    const data = await res.json();

    if (res.ok && data?.messages?.[0]?.id) {
      const messageId = data.messages[0].id;
      console.log(`[Notifications] WhatsApp message sent successfully via Cloud API. Message ID: ${messageId}`);
      return {
        status: 'sent',
        recipient,
        provider: 'WhatsApp Business Cloud API',
        sentAt: new Date().toISOString(),
        messageId,
      };
    } else {
      const errMsg = data?.error?.message || `HTTP ${res.status}: ${res.statusText}`;
      console.error(`[Notifications] WhatsApp Cloud API delivery failed:`, errMsg);
      return {
        status: 'failed',
        recipient,
        provider: 'WhatsApp Business Cloud API',
        error: errMsg,
      };
    }
  } catch (err: any) {
    console.error(`[Notifications] Network error calling WhatsApp Cloud API:`, err);
    return {
      status: 'failed',
      recipient,
      provider: 'WhatsApp Business Cloud API',
      error: err?.message || 'Network error connecting to Meta WhatsApp Cloud API',
    };
  }
}

/**
 * Dispatches notifications to both Email and WhatsApp in parallel after order is saved
 */
export async function sendOrderNotifications(order: Order): Promise<OrderNotifications> {
  const [emailResult, whatsappResult] = await Promise.all([
    sendOrderEmailNotification(order),
    sendOrderWhatsAppNotification(order),
  ]);

  return {
    email: emailResult,
    whatsapp: whatsappResult,
  };
}

/**
 * Retries notifications safely for an existing order
 */
export async function retryOrderNotifications(
  order: Order,
  channel: 'all' | 'email' | 'whatsapp' = 'all'
): Promise<OrderNotifications> {
  const current = order.notifications || {
    email: { status: 'pending', recipient: process.env.ORDER_NOTIFICATION_EMAIL || STORE_OWNER_EMAIL },
    whatsapp: { status: 'pending', recipient: process.env.WHATSAPP_RECIPIENT_NUMBER || STORE_OWNER_WHATSAPP },
  };

  let emailResult = current.email;
  let whatsappResult = current.whatsapp;

  if (channel === 'all' || channel === 'email') {
    emailResult = await sendOrderEmailNotification(order);
  }

  if (channel === 'all' || channel === 'whatsapp') {
    whatsappResult = await sendOrderWhatsAppNotification(order);
  }

  return {
    email: emailResult,
    whatsapp: whatsappResult,
  };
}
