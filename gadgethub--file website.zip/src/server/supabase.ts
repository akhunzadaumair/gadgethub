import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { Product, Category, Order, OrderStatus } from '../types';

let cachedClient: SupabaseClient | null = null;
let lastUsedConfig = '';

export function getCleanSupabaseConfig() {
  const rawUrl = process.env.SUPABASE_URL || '';
  // Clean off accidental "Copy URL" button text and trailing whitespace/slashes
  const cleanUrl = rawUrl.replace(/\s+Copy\s+URL.*/i, '').trim().replace(/\/+$/, '');
  const serviceRoleKey = (process.env.SUPABASE_SERVICE_ROLE_KEY || '').trim();
  const anonKey = (process.env.SUPABASE_KEY || '').trim();
  const activeKey = serviceRoleKey || anonKey;

  const isConfigured = Boolean(
    cleanUrl &&
    activeKey &&
    !cleanUrl.includes('your-project') &&
    !activeKey.includes('your-anon')
  );

  return {
    url: cleanUrl,
    key: activeKey,
    hasServiceRoleKey: Boolean(serviceRoleKey),
    isConfigured,
  };
}

export function getSupabaseClient(): SupabaseClient | null {
  const config = getCleanSupabaseConfig();
  if (!config.isConfigured) {
    return null;
  }

  const configSignature = `${config.url}::${config.key}`;
  if (cachedClient && lastUsedConfig === configSignature) {
    return cachedClient;
  }

  try {
    cachedClient = createClient(config.url, config.key, {
      auth: {
        persistSession: false,
        autoRefreshToken: false,
      },
    });
    lastUsedConfig = configSignature;
    return cachedClient;
  } catch (err) {
    console.error('[Supabase] Client initialization error:', err);
    return null;
  }
}

// Convert PostgreSQL snake_case rows to App CamelCase types
export function mapDbProductToApp(dbProd: any): Product {
  return {
    id: dbProd.id,
    title: dbProd.title,
    slug: dbProd.slug || dbProd.title.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
    category: dbProd.category,
    categoryId: dbProd.category_id || 'mobiles',
    brand: dbProd.brand,
    price: Number(dbProd.price),
    originalPrice: Number(dbProd.original_price ?? dbProd.price),
    discountPercent: Number(dbProd.discount_percent ?? 0),
    stock: Number(dbProd.stock ?? 0),
    rating: Number(dbProd.rating ?? 5.0),
    reviewCount: Number(dbProd.review_count ?? 0),
    images: Array.isArray(dbProd.images)
      ? dbProd.images
      : typeof dbProd.images === 'string'
      ? [dbProd.images]
      : [],
    description: dbProd.description || '',
    specs: typeof dbProd.specs === 'object' && dbProd.specs !== null ? dbProd.specs : {},
    isFeatured: Boolean(dbProd.is_featured),
    isBestSeller: Boolean(dbProd.is_best_seller),
    isNewArrival: Boolean(dbProd.is_new_arrival),
    isTradeAssurance: Boolean(dbProd.is_trade_assurance ?? true),
    moq: Number(dbProd.moq ?? 1),
    wholesalePrice: dbProd.wholesale_price ? Number(dbProd.wholesale_price) : undefined,
    sku: dbProd.sku || `GH-SKU-${dbProd.id}`,
    warranty: dbProd.warranty || '1 Year Official Warranty',
  };
}

export function mapAppProductToDb(prod: Omit<Product, 'id'> & { id?: string }): any {
  return {
    id: prod.id,
    title: prod.title,
    slug: prod.slug,
    category: prod.category,
    category_id: prod.categoryId,
    brand: prod.brand,
    price: prod.price,
    original_price: prod.originalPrice || prod.price,
    discount_percent: prod.discountPercent || 0,
    stock: prod.stock,
    rating: prod.rating || 5.0,
    review_count: prod.reviewCount || 0,
    images: prod.images || [],
    description: prod.description || '',
    specs: prod.specs || {},
    is_featured: Boolean(prod.isFeatured),
    is_best_seller: Boolean(prod.isBestSeller),
    is_new_arrival: Boolean(prod.isNewArrival),
    is_trade_assurance: Boolean(prod.isTradeAssurance ?? true),
    moq: prod.moq || 1,
    wholesale_price: prod.wholesalePrice || null,
    sku: prod.sku || null,
    warranty: prod.warranty || '1 Year Official Warranty',
  };
}

export function mapDbCategoryToApp(dbCat: any): Category {
  return {
    id: dbCat.id,
    name: dbCat.name,
    slug: dbCat.slug,
    iconName: dbCat.icon_name || 'Smartphone',
    description: dbCat.description || '',
    itemCount: Number(dbCat.item_count ?? 0),
  };
}

export function mapAppCategoryToDb(cat: Category): any {
  return {
    id: cat.id,
    name: cat.name,
    slug: cat.slug,
    icon_name: cat.iconName,
    description: cat.description,
    item_count: cat.itemCount,
  };
}

export function mapOrderToDb(order: Order): any {
  return {
    id: order.id,
    date: order.date,
    customer: order.customer,
    items: order.items,
    subtotal: order.subtotal,
    shipping_fee: order.shippingFee,
    discount: order.discount,
    total: order.total,
    payment_method: order.paymentMethod,
    status: order.status,
    tracking_number: order.trackingNumber,
    courier_name: order.courierName,
  };
}

export function mapDbOrderToApp(dbOrder: any): Order {
  return {
    id: dbOrder.id,
    date: dbOrder.date || dbOrder.created_at,
    customer: dbOrder.customer,
    items: dbOrder.items || [],
    subtotal: Number(dbOrder.subtotal),
    shippingFee: Number(dbOrder.shipping_fee ?? 0),
    discount: Number(dbOrder.discount ?? 0),
    total: Number(dbOrder.total),
    paymentMethod: dbOrder.payment_method || 'cod',
    status: dbOrder.status || 'Pending',
    trackingNumber: dbOrder.tracking_number || '',
    courierName: dbOrder.courier_name || 'TCS Express Pakistan',
    notifications: dbOrder.notifications || undefined,
  };
}

/**
 * Fetch all categories directly from Supabase
 */
export async function getSupabaseCategories(): Promise<Category[] | null> {
  const client = getSupabaseClient();
  if (!client) return null;

  try {
    const { data, error } = await client
      .from('categories')
      .select('*')
      .order('name', { ascending: true });

    if (error) {
      console.error('[Supabase] Failed to fetch categories:', error.message);
      return null;
    }

    return (data || []).map(mapDbCategoryToApp);
  } catch (err) {
    console.error('[Supabase] Categories query exception:', err);
    return null;
  }
}

/**
 * Fetch all products directly from Supabase
 */
export async function getSupabaseProducts(): Promise<Product[] | null> {
  const client = getSupabaseClient();
  if (!client) return null;

  try {
    const { data, error } = await client
      .from('products')
      .select('*')
      .order('is_featured', { ascending: false })
      .order('created_at', { ascending: false });

    if (error) {
      console.error('[Supabase] Failed to fetch products:', error.message);
      return null;
    }

    return (data || []).map(mapDbProductToApp);
  } catch (err) {
    console.error('[Supabase] Products query exception:', err);
    return null;
  }
}

/**
 * Insert new order into Supabase orders table
 */
export async function saveOrderToSupabase(order: Order): Promise<{ success: boolean; error?: string }> {
  const client = getSupabaseClient();
  if (!client) {
    return { success: false, error: 'Supabase client not configured' };
  }

  try {
    const payload = mapOrderToDb(order);
    const { error } = await client
      .from('orders')
      .insert(payload);

    if (error) {
      console.error('[Supabase] Failed to insert order:', error.message);
      return { success: false, error: error.message };
    }

    console.log(`[Supabase] Successfully saved order ${order.id} to cloud PostgreSQL database.`);
    return { success: true };
  } catch (err: any) {
    console.error('[Supabase] Order insert exception:', err);
    return { success: false, error: err?.message || 'Database insert exception' };
  }
}

/**
 * Decrement product stock in Supabase products table
 */
export async function deductSupabaseProductStock(
  productId: string,
  deductQuantity: number
): Promise<{ success: boolean; remainingStock?: number }> {
  const client = getSupabaseClient();
  if (!client) return { success: false };

  try {
    // Read current stock first
    const { data, error: readErr } = await client
      .from('products')
      .select('stock')
      .eq('id', productId)
      .maybeSingle();

    if (readErr || !data) {
      console.warn(`[Supabase] Product ${productId} not found to deduct stock.`);
      return { success: false };
    }

    const currentStock = Number(data.stock ?? 0);
    const newStock = Math.max(0, currentStock - deductQuantity);

    const { error: updateErr } = await client
      .from('products')
      .update({ stock: newStock })
      .eq('id', productId);

    if (updateErr) {
      console.error(`[Supabase] Failed to update stock for ${productId}:`, updateErr.message);
      return { success: false };
    }

    return { success: true, remainingStock: newStock };
  } catch (err) {
    console.error(`[Supabase] Stock update exception:`, err);
    return { success: false };
  }
}

/**
 * Update an order's status in Supabase
 */
export async function updateSupabaseOrderStatus(
  orderId: string,
  status: OrderStatus
): Promise<{ success: boolean }> {
  const client = getSupabaseClient();
  if (!client) return { success: false };

  try {
    const { error } = await client
      .from('orders')
      .update({ status })
      .eq('id', orderId);

    if (error) {
      console.warn(`[Supabase] Note: Order status update in cloud: ${error.message}`);
      return { success: false };
    }
    return { success: true };
  } catch (err) {
    console.error('[Supabase] Order status update exception:', err);
    return { success: false };
  }
}

/**
 * Delete an order from Supabase
 */
export async function deleteSupabaseOrder(orderId: string): Promise<{ success: boolean; error?: string }> {
  const client = getSupabaseClient();
  if (!client) return { success: false, error: 'Supabase client not configured' };

  try {
    const { error } = await client
      .from('orders')
      .delete()
      .eq('id', orderId);

    if (error) {
      console.warn(`[Supabase] Note: Order delete in cloud: ${error.message}`);
      return { success: false, error: error.message };
    }
    console.log(`[Supabase] Successfully deleted order ${orderId} from Supabase.`);
    return { success: true };
  } catch (err: any) {
    console.error('[Supabase] Order deletion exception:', err);
    return { success: false, error: err?.message || 'Database delete exception' };
  }
}

/**
 * Fetch orders from Supabase (supported if service_role key is configured or user JWT is provided)
 */
export async function getSupabaseOrders(): Promise<Order[] | null> {
  const client = getSupabaseClient();
  if (!client) return null;

  try {
    const { data, error } = await client
      .from('orders')
      .select('*')
      .order('date', { ascending: false });

    if (error) {
      // Row Level Security on anon key will return empty/permission notice
      return null;
    }

    if (Array.isArray(data) && data.length > 0) {
      return data.map(mapDbOrderToApp);
    }
    return null;
  } catch (err) {
    return null;
  }
}

/**
 * Checks detailed Supabase connection status for health check
 */
export async function checkSupabaseHealth() {
  const config = getCleanSupabaseConfig();
  if (!config.isConfigured) {
    return {
      connected: false,
      url: config.url || 'Not set',
      hasKey: Boolean(config.key),
      hasServiceRoleKey: false,
      message: 'SUPABASE_URL and SUPABASE_KEY / SUPABASE_SERVICE_ROLE_KEY missing in environment',
      categoryCount: 0,
      productCount: 0,
      orderCount: 0,
    };
  }

  const client = getSupabaseClient();
  if (!client) {
    return {
      connected: false,
      url: config.url,
      hasKey: true,
      hasServiceRoleKey: config.hasServiceRoleKey,
      message: 'Failed to initialize Supabase client with given credentials',
      categoryCount: 0,
      productCount: 0,
      orderCount: 0,
    };
  }

  try {
    const [catRes, prodRes] = await Promise.all([
      client.from('categories').select('id', { count: 'exact', head: true }),
      client.from('products').select('id', { count: 'exact', head: true }),
    ]);

    const isHealthy = !catRes.error && !prodRes.error;

    return {
      connected: isHealthy,
      url: config.url,
      hasKey: true,
      hasServiceRoleKey: config.hasServiceRoleKey,
      categoryCount: catRes.count ?? 0,
      productCount: prodRes.count ?? 0,
      message: isHealthy
        ? `Connected to Supabase PostgreSQL at ${config.url}`
        : `Connection error: ${catRes.error?.message || prodRes.error?.message}`,
    };
  } catch (err: any) {
    return {
      connected: false,
      url: config.url,
      hasKey: true,
      hasServiceRoleKey: config.hasServiceRoleKey,
      message: err?.message || 'Failed connecting to Supabase cloud database',
      categoryCount: 0,
      productCount: 0,
    };
  }
}
