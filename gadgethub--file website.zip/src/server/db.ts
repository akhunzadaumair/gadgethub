import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { Product, Category, Order, OrderStatus, OrderNotifications } from '../types';
import { INITIAL_PRODUCTS, INITIAL_CATEGORIES, INITIAL_ORDERS } from '../data/initialData';
import {
  getCleanSupabaseConfig,
  getSupabaseCategories,
  getSupabaseProducts,
  saveOrderToSupabase,
  deductSupabaseProductStock,
  updateSupabaseOrderStatus,
  deleteSupabaseOrder,
  getSupabaseOrders,
  checkSupabaseHealth,
} from './supabase';
import {
  sendOrderNotifications,
  retryOrderNotifications,
  getNotificationServiceStatus,
  STORE_OWNER_EMAIL,
  STORE_OWNER_WHATSAPP,
} from './notifications';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'gadgethub_db.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

interface DatabaseStructure {
  products: Product[];
  categories: Category[];
  orders: Order[];
  adminTokens: Record<string, { createdAt: string; expiresAt: string }>;
  deletedOrderIds?: string[];
  version: string;
}

class DatabaseManager {
  private data: DatabaseStructure;
  private isSupabaseSyncing = false;

  constructor() {
    this.data = this.loadDatabase();
    // Synchronize catalog with Supabase on server startup
    this.syncWithSupabase().catch((err) => {
      console.warn('[DB] Initial Supabase sync deferred:', err?.message || err);
    });
  }

  private loadDatabase(): DatabaseStructure {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        if (parsed.products && parsed.categories && parsed.orders) {
          return {
            products: parsed.products,
            categories: parsed.categories,
            orders: parsed.orders,
            adminTokens: parsed.adminTokens || {},
            deletedOrderIds: parsed.deletedOrderIds || [],
            version: parsed.version || '1.1.0',
          };
        }
      }
    } catch (err) {
      console.error('[DB] Failed reading database file, initializing defaults:', err);
    }

    // Default structure with initial data
    const initialDb: DatabaseStructure = {
      products: INITIAL_PRODUCTS,
      categories: INITIAL_CATEGORIES,
      orders: INITIAL_ORDERS,
      adminTokens: {},
      version: '1.1.0',
    };

    this.saveToDisk(initialDb);
    return initialDb;
  }

  private saveToDisk(dataToSave?: DatabaseStructure) {
    try {
      const data = dataToSave || this.data;
      fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (err) {
      console.error('[DB] Failed writing database file:', err);
    }
  }

  /**
   * Synchronize products and categories with Supabase PostgreSQL cloud database
   */
  public async syncWithSupabase() {
    if (this.isSupabaseSyncing) return;
    this.isSupabaseSyncing = true;

    try {
      const [remoteCategories, remoteProducts, remoteOrders] = await Promise.all([
        getSupabaseCategories(),
        getSupabaseProducts(),
        getSupabaseOrders(),
      ]);

      if (remoteCategories && remoteCategories.length > 0) {
        this.data.categories = remoteCategories;
        console.log(`[DB] Synchronized ${remoteCategories.length} categories from Supabase.`);
      }

      if (remoteProducts && remoteProducts.length > 0) {
        this.data.products = remoteProducts;
        console.log(`[DB] Synchronized ${remoteProducts.length} products from Supabase.`);
      }

      if (remoteOrders && remoteOrders.length > 0) {
        // Merge Supabase orders with local orders, avoiding duplicates and deleted orders
        const deletedSet = new Set(this.data.deletedOrderIds || []);
        const existingIds = new Set(this.data.orders.map((o) => o.id));
        for (const order of remoteOrders) {
          if (!existingIds.has(order.id) && !deletedSet.has(order.id)) {
            this.data.orders.push(order);
          }
        }
      }

      this.saveToDisk();
    } catch (err) {
      console.warn('[DB] Supabase synchronization warning:', err);
    } finally {
      this.isSupabaseSyncing = false;
    }
  }

  // --- Products ---
  public getProducts(): Product[] {
    return [...this.data.products];
  }

  public getProductById(id: string): Product | undefined {
    return this.data.products.find((p) => p.id === id);
  }

  public addProduct(productData: Omit<Product, 'id'>): Product {
    const id = `gh-prod-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const newProduct: Product = {
      ...productData,
      id,
      slug: productData.slug || productData.title.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
    };

    this.data.products.unshift(newProduct);
    this.saveToDisk();
    return newProduct;
  }

  public updateProduct(id: string, updates: Partial<Product>): Product | null {
    const index = this.data.products.findIndex((p) => p.id === id);
    if (index === -1) return null;

    const updated = {
      ...this.data.products[index],
      ...updates,
      id, // Preserve original id
    };

    this.data.products[index] = updated;
    this.saveToDisk();
    return updated;
  }

  public deleteProduct(id: string): boolean {
    const initialLen = this.data.products.length;
    this.data.products = this.data.products.filter((p) => p.id !== id);
    if (this.data.products.length !== initialLen) {
      this.saveToDisk();
      return true;
    }
    return false;
  }

  // --- Categories ---
  public getCategories(): Category[] {
    return [...this.data.categories];
  }

  public addCategory(cat: Category): Category {
    const existing = this.data.categories.find((c) => c.id === cat.id);
    if (existing) return existing;
    this.data.categories.push(cat);
    this.saveToDisk();
    return cat;
  }

  // --- Orders & Server-Side Validation ---
  public getOrders(): Order[] {
    return [...this.data.orders];
  }

  public getOrderByIdOrTracking(lookupId: string): Order | undefined {
    const clean = lookupId.trim().toUpperCase();
    return this.data.orders.find(
      (o) => o.id.toUpperCase() === clean || o.trackingNumber.toUpperCase() === clean
    );
  }

  /**
   * Validates and places a customer order:
   * 1. Validates customer address & contact
   * 2. Validates item availability and inventory stock
   * 3. Validates price calculations and shipping fees on server
   * 4. Saves order to Supabase cloud database
   * 5. Decrements stock in database
   * 6. Dispatches Email & WhatsApp notifications to store owner
   */
  public async createValidatedOrder(orderPayload: {
    customer: any;
    items: any[];
    subtotal: number;
    shippingFee: number;
    discount: number;
    total: number;
    paymentMethod: string;
    courierName?: string;
  }): Promise<Order> {
    const { customer, items, paymentMethod } = orderPayload;

    // 1. Validate Customer
    if (!customer || !customer.fullName || !customer.phone || !customer.address || !customer.city) {
      throw new Error('Customer full name, mobile number, address, and city are required.');
    }

    // 2. Validate Items Array
    if (!items || !Array.isArray(items) || items.length === 0) {
      throw new Error('Order must contain at least one item.');
    }

    // 3. Server-side Inventory Stock & Price Validation
    let calculatedSubtotal = 0;
    const validatedItems = [];

    for (const item of items) {
      const prodId = item.product?.id;
      const quantity = Math.max(1, parseInt(item.quantity, 10) || 1);

      const dbProduct = this.getProductById(prodId);
      if (!dbProduct) {
        throw new Error(`Product "${item.product?.title || prodId}" is no longer available in the catalog.`);
      }

      if (dbProduct.stock < quantity) {
        throw new Error(
          `Insufficient stock for "${dbProduct.title}". Requested: ${quantity}, Available: ${dbProduct.stock} unit(s).`
        );
      }

      // Check wholesale pricing rule: 3+ units eligible for wholesale price if defined
      const unitPrice =
        quantity >= 3 && dbProduct.wholesalePrice ? dbProduct.wholesalePrice : dbProduct.price;

      calculatedSubtotal += unitPrice * quantity;

      validatedItems.push({
        product: dbProduct,
        quantity,
        selectedColor: item.selectedColor,
        selectedVariant: item.selectedVariant,
      });
    }

    // 4. Validate Delivery Fee (Free shipping on orders >= Rs. 5,000, otherwise Rs. 350)
    const expectedShipping = calculatedSubtotal >= 5000 ? 0 : 350;
    const claimedDiscount = Math.max(0, Number(orderPayload.discount) || 0);
    const calculatedTotal = Math.max(0, calculatedSubtotal + expectedShipping - claimedDiscount);

    // 5. Generate Order Identifiers
    const courierOptions = ['TCS Express Pakistan', 'Leopards Courier', 'PostEx Logistics', 'Trax Express'];
    const assignedCourier =
      orderPayload.courierName || courierOptions[Math.floor(Math.random() * courierOptions.length)];
    const trackingPrefix = assignedCourier.slice(0, 3).toUpperCase();
    const trackingNumber = `${trackingPrefix}-PK-${Math.floor(1000000 + Math.random() * 9000000)}`;

    const newOrder: Order = {
      id: `GH-PK-${Math.floor(10000 + Math.random() * 90000)}`,
      date: new Date().toISOString(),
      customer: {
        fullName: customer.fullName.trim(),
        email: (customer.email || 'customer@gadgethub.pk').trim(),
        phone: customer.phone.trim(),
        address: customer.address.trim(),
        city: customer.city.trim(),
        province: customer.province || 'Pakistan',
        postalCode: customer.postalCode || '54000',
        orderNotes: customer.orderNotes || '',
      },
      items: validatedItems,
      subtotal: calculatedSubtotal,
      shippingFee: expectedShipping,
      discount: claimedDiscount,
      total: calculatedTotal,
      paymentMethod: (paymentMethod as any) || 'cod',
      status: paymentMethod === 'cod' ? 'Confirmed' : 'Pending',
      trackingNumber,
      courierName: assignedCourier,
      notifications: {
        email: {
          status: 'pending',
          recipient: process.env.ORDER_NOTIFICATION_EMAIL || STORE_OWNER_EMAIL,
        },
        whatsapp: {
          status: 'pending',
          recipient: process.env.WHATSAPP_RECIPIENT_NUMBER || STORE_OWNER_WHATSAPP,
        },
      },
    };

    // 6. Deduct stock in memory and in Supabase
    for (const item of newOrder.items) {
      const prod = this.data.products.find((p) => p.id === item.product.id);
      if (prod) {
        prod.stock = Math.max(0, prod.stock - item.quantity);
      }
      // Cloud Supabase stock decrement
      deductSupabaseProductStock(item.product.id, item.quantity).catch((err) => {
        console.warn(`[Supabase] Cloud stock deduct notice for ${item.product.id}:`, err);
      });
    }

    // 7. Save to Supabase orders table
    const supabaseSave = await saveOrderToSupabase(newOrder);
    if (!supabaseSave.success) {
      console.warn(`[Supabase] Order saved locally. Supabase write notice: ${supabaseSave.error}`);
    }

    // 8. Trigger Email and WhatsApp notifications to store owner
    try {
      const notificationResults = await sendOrderNotifications(newOrder);
      newOrder.notifications = notificationResults;
    } catch (notifErr: any) {
      console.error('[Notifications] Failed dispatching order alerts:', notifErr);
      newOrder.notifications = {
        email: {
          status: 'failed',
          recipient: process.env.ORDER_NOTIFICATION_EMAIL || STORE_OWNER_EMAIL,
          error: notifErr?.message || 'Failed dispatching email alert',
        },
        whatsapp: {
          status: 'failed',
          recipient: process.env.WHATSAPP_RECIPIENT_NUMBER || STORE_OWNER_WHATSAPP,
          error: notifErr?.message || 'Failed dispatching WhatsApp alert',
        },
      };
    }

    // 9. Persist Order locally
    this.data.orders.unshift(newOrder);
    this.saveToDisk();

    return newOrder;
  }

  /**
   * Retries email and/or WhatsApp notifications for an existing order
   */
  public async retryNotification(
    orderId: string,
    channel: 'all' | 'email' | 'whatsapp' = 'all'
  ): Promise<{ success: boolean; order?: Order; error?: string }> {
    const order = this.data.orders.find((o) => o.id === orderId);
    if (!order) {
      return { success: false, error: 'Order not found' };
    }

    try {
      const updatedNotifications = await retryOrderNotifications(order, channel);
      order.notifications = updatedNotifications;
      this.saveToDisk();
      return { success: true, order };
    } catch (err: any) {
      return { success: false, error: err?.message || 'Failed to retry notification' };
    }
  }

  public updateOrderStatus(orderId: string, status: OrderStatus): Order | null {
    const order = this.data.orders.find((o) => o.id === orderId);
    if (!order) return null;

    order.status = status;
    this.saveToDisk();

    // Sync status change to Supabase
    updateSupabaseOrderStatus(orderId, status).catch(() => {});

    return order;
  }

  public deleteOrder(orderId: string): boolean {
    const initialLen = this.data.orders.length;
    this.data.orders = this.data.orders.filter((o) => o.id !== orderId);
    if (!this.data.deletedOrderIds) {
      this.data.deletedOrderIds = [];
    }
    if (!this.data.deletedOrderIds.includes(orderId)) {
      this.data.deletedOrderIds.push(orderId);
    }
    deleteSupabaseOrder(orderId).catch((err) => {
      console.warn(`[Supabase] Cloud order delete notice for ${orderId}:`, err);
    });
    this.saveToDisk();
    return true;
  }

  // --- Admin Security & Auth ---
  public getAdminAuthConfig(): { isConfigured: boolean; error?: string } {
    const rawPass = process.env.ADMIN_PASSWORD;
    if (!rawPass || typeof rawPass !== 'string' || rawPass.trim() === '') {
      return {
        isConfigured: false,
        error: 'ADMIN_PASSWORD environment variable is not configured. Please set ADMIN_PASSWORD in your environment or .env file.',
      };
    }
    return { isConfigured: true };
  }

  public authenticateAdmin(password: string): { success: boolean; token?: string; error?: string; status?: number } {
    const authConfig = this.getAdminAuthConfig();
    if (!authConfig.isConfigured) {
      return {
        success: false,
        status: 500,
        error: authConfig.error || 'ADMIN_PASSWORD environment variable is not configured.',
      };
    }

    const expectedPassword = (process.env.ADMIN_PASSWORD || '').trim();
    const providedPassword = (password || '').trim();

    if (!providedPassword) {
      return {
        success: false,
        status: 400,
        error: 'Password cannot be empty.',
      };
    }

    // Timing-safe comparison
    const expectedBuffer = Buffer.from(expectedPassword);
    const providedBuffer = Buffer.from(providedPassword);

    let isMatch = false;
    if (expectedBuffer.length === providedBuffer.length && crypto.timingSafeEqual(expectedBuffer, providedBuffer)) {
      isMatch = true;
    } else {
      const cleanExpected = expectedPassword.replace(/[\u200B-\u200D\uFEFF]/g, '').replace(/^["'“”‘’]|["'“”‘’]$/g, '').trim();
      const cleanProvided = providedPassword.replace(/[\u200B-\u200D\uFEFF]/g, '').replace(/^["'“”‘’]|["'“”‘’]$/g, '').trim();
      if (cleanExpected && cleanProvided && cleanExpected === cleanProvided) {
        isMatch = true;
      }
    }

    if (isMatch) {
      const token = crypto.randomBytes(32).toString('hex');
      const now = new Date();
      const expiresAt = new Date(now.getTime() + 24 * 60 * 60 * 1000).toISOString(); // 24 hours

      this.data.adminTokens[token] = {
        createdAt: now.toISOString(),
        expiresAt,
      };
      this.saveToDisk();
      return { success: true, token };
    }

    return {
      success: false,
      status: 401,
      error: 'Invalid administrator password. Please check the ADMIN_PASSWORD configured in your environment.',
    };
  }

  public verifyAdminToken(token: string): boolean {
    if (!token) return false;
    const session = this.data.adminTokens[token];
    if (!session) return false;

    if (new Date(session.expiresAt) < new Date()) {
      delete this.data.adminTokens[token];
      this.saveToDisk();
      return false;
    }
    return true;
  }

  public revokeAdminToken(token: string) {
    if (this.data.adminTokens[token]) {
      delete this.data.adminTokens[token];
      this.saveToDisk();
    }
  }

  public resetToDefaults() {
    this.data.products = [...INITIAL_PRODUCTS];
    this.data.categories = [...INITIAL_CATEGORIES];
    this.data.orders = [...INITIAL_ORDERS];
    this.saveToDisk();
  }

  public async getDbStatus() {
    const supabaseHealth = await checkSupabaseHealth();
    const notificationHealth = getNotificationServiceStatus();

    return {
      connected: true,
      supabaseConnected: supabaseHealth.connected,
      storageType: supabaseHealth.connected
        ? `Connected to Supabase PostgreSQL Database (${supabaseHealth.url})`
        : 'Local Persistent JSON Engine (Supabase ready in schema.sql)',
      supabaseStatus: supabaseHealth.message,
      supabaseDetails: {
        url: supabaseHealth.url,
        hasKey: supabaseHealth.hasKey,
        hasServiceRoleKey: supabaseHealth.hasServiceRoleKey,
        categoryCount: supabaseHealth.categoryCount,
        productCount: supabaseHealth.productCount,
      },
      notifications: notificationHealth,
      productCount: this.data.products.length,
      orderCount: this.data.orders.length,
      categoryCount: this.data.categories.length,
      activeAdminSessions: Object.keys(this.data.adminTokens).length,
    };
  }
}

export const db = new DatabaseManager();
