import React, { useMemo } from 'react';
import { SlidersHorizontal, ArrowUpDown, X, Sparkles, Filter, Check } from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { ProductCard } from './ProductCard';

export const ProductGrid: React.FC = () => {
  const { products, categories, filters, setFilters, resetFilters } = useStore();

  // Filter & sort logic
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      // Search
      if (filters.searchQuery) {
        const query = filters.searchQuery.toLowerCase();
        const matchesTitle = p.title.toLowerCase().includes(query);
        const matchesBrand = p.brand.toLowerCase().includes(query);
        const matchesCat = p.category.toLowerCase().includes(query);
        const matchesDesc = p.description.toLowerCase().includes(query);
        if (!matchesTitle && !matchesBrand && !matchesCat && !matchesDesc) {
          return false;
        }
      }

      // Category
      if (filters.categoryId !== 'all' && p.categoryId !== filters.categoryId) {
        return false;
      }

      // In stock
      if (filters.inStockOnly && p.stock <= 0) {
        return false;
      }

      // Price range
      if (p.price < filters.minPrice || p.price > filters.maxPrice) {
        return false;
      }

      return true;
    }).sort((a, b) => {
      if (filters.sortBy === 'price-asc') return a.price - b.price;
      if (filters.sortBy === 'price-desc') return b.price - a.price;
      if (filters.sortBy === 'rating') return b.rating - a.rating;
      if (filters.sortBy === 'newest') return (b.isNewArrival ? 1 : 0) - (a.isNewArrival ? 1 : 0);
      // default 'featured'
      return (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0);
    });
  }, [products, filters]);

  const activeCategoryName = useMemo(() => {
    if (filters.categoryId === 'all') return 'All Tech Departments';
    const cat = categories.find((c) => c.id === filters.categoryId);
    return cat ? cat.name : 'All Products';
  }, [filters.categoryId, categories]);

  const hasActiveFilters =
    filters.searchQuery !== '' ||
    filters.categoryId !== 'all' ||
    filters.inStockOnly ||
    filters.sortBy !== 'featured';

  return (
    <section id="products-section" className="py-10 max-w-7xl mx-auto px-4 sm:px-6">
      {/* Section Header & Interactive Controls */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Marketplace Catalog</span>
            <span aria-hidden="true">·</span>
            <span className="font-semibold text-slate-700">{filteredProducts.length} items found</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            {activeCategoryName}
          </h2>
        </div>

        {/* Sort & Filter Controls */}
        <div className="flex flex-wrap items-center gap-3">
          {/* In Stock Only Checkbox */}
          <label className="flex items-center gap-2 text-xs font-medium text-slate-700 bg-slate-50 border border-slate-200 py-2 px-3 rounded-lg cursor-pointer hover:bg-slate-100 transition-colors">
            <input
              type="checkbox"
              checked={filters.inStockOnly}
              onChange={(e) => setFilters((prev) => ({ ...prev, inStockOnly: e.target.checked }))}
              className="rounded border-slate-300 text-slate-900 focus:ring-0"
            />
            <span>In Stock Only</span>
          </label>

          {/* Sort Selector */}
          <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 py-1.5 px-3 rounded-lg">
            <ArrowUpDown className="w-3.5 h-3.5 text-slate-500" />
            <select
              value={filters.sortBy}
              onChange={(e) =>
                setFilters((prev) => ({
                  ...prev,
                  sortBy: e.target.value as any,
                }))
              }
              aria-label="Sort products by"
              className="bg-transparent text-xs font-medium text-slate-800 focus:outline-none cursor-pointer"
            >
              <option value="featured">Featured First</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="rating">Highest Rated</option>
              <option value="newest">New Arrivals</option>
            </select>
          </div>

          {hasActiveFilters && (
            <button
              onClick={resetFilters}
              className="text-xs font-semibold text-red-600 hover:text-red-700 flex items-center gap-1 py-2 px-2.5 rounded-lg border border-red-200 bg-red-50 hover:bg-red-100 transition-colors cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
              <span>Reset Filters</span>
            </button>
          )}
        </div>
      </div>

      {/* Active Filter Chips Bar */}
      {hasActiveFilters && (
        <div className="flex flex-wrap items-center gap-2 pt-4 text-xs text-slate-600">
          <span className="font-semibold text-slate-700">Active filters:</span>
          {filters.searchQuery && (
            <span className="bg-slate-100 text-slate-800 px-2.5 py-1 rounded-md flex items-center gap-1">
              Search: "{filters.searchQuery}"
              <button
                onClick={() => setFilters((prev) => ({ ...prev, searchQuery: '' }))}
                className="hover:text-slate-950"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          )}
          {filters.categoryId !== 'all' && (
            <span className="bg-slate-100 text-slate-800 px-2.5 py-1 rounded-md flex items-center gap-1">
              Category: {activeCategoryName}
              <button
                onClick={() => setFilters((prev) => ({ ...prev, categoryId: 'all' }))}
                className="hover:text-slate-950"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          )}
        </div>
      )}

      {/* Product Cards Grid */}
      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 pt-6">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        /* Empty State */
        <div className="text-center py-16 px-4 bg-slate-50 rounded-xl border border-dashed border-slate-200 mt-6">
          <div className="w-12 h-12 mx-auto rounded-full bg-slate-200/80 flex items-center justify-center text-slate-500 mb-3">
            <Filter className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-900">No products match your criteria</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto mt-1 mb-4">
            Try adjusting your search terms, changing the category, or clearing filters.
          </p>
          <button
            onClick={resetFilters}
            className="bg-slate-900 text-white text-xs font-semibold py-2 px-4 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            Clear All Filters
          </button>
        </div>
      )}
    </section>
  );
};
