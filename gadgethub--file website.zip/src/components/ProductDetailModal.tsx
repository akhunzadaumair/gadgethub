import React, { useState, useEffect } from 'react';
import {
  X,
  Star,
  ShieldCheck,
  Truck,
  RotateCcw,
  Check,
  Heart,
  Share2,
  ShoppingBag,
  Zap,
  Info,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { PAKISTAN_CITIES } from '../data/initialData';

interface ProductDetailModalProps {
  onOpenCheckout: () => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({ onOpenCheckout }) => {
  const {
    selectedProduct,
    setSelectedProduct,
    addToCart,
    isInWishlist,
    toggleWishlist,
  } = useStore();

  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [selectedCity, setSelectedCity] = useState('Lahore');
  const [copiedShare, setCopiedShare] = useState(false);
  const [addedNotice, setAddedNotice] = useState(false);

  useEffect(() => {
    setActiveImageIndex(0);
    setQuantity(1);
    setAddedNotice(false);
  }, [selectedProduct?.id]);

  if (!selectedProduct) return null;

  const isWish = isInWishlist(selectedProduct.id);
  const effectiveWholesale =
    quantity >= 3 && selectedProduct.wholesalePrice
      ? selectedProduct.wholesalePrice
      : selectedProduct.price;

  const handleAddToCart = () => {
    addToCart(selectedProduct, quantity);
    setAddedNotice(true);
    setTimeout(() => setAddedNotice(false), 2000);
  };

  const handleBuyNow = () => {
    addToCart(selectedProduct, quantity);
    setSelectedProduct(null);
    onOpenCheckout();
  };

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopiedShare(true);
    setTimeout(() => setCopiedShare(false), 2000);
  };

  // Delivery estimation based on selected city
  const getDeliveryEstimate = (city: string) => {
    if (city === 'Lahore') return 'Next-Day Delivery via TCS Express (1-2 Days)';
    if (['Karachi', 'Islamabad', 'Rawalpindi'].includes(city)) return '2-3 Business Days via Air Express';
    return '3-4 Business Days via Nationwide Surface Express';
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div
        className="relative bg-white w-full max-w-5xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50 shrink-0">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span className="font-semibold text-slate-800">{selectedProduct.brand}</span>
            <span aria-hidden="true">·</span>
            <span className="text-slate-600">{selectedProduct.category}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono text-slate-400">SKU: {selectedProduct.sku}</span>
          </div>
          <button
            onClick={() => setSelectedProduct(null)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors cursor-pointer"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="overflow-y-auto p-6 sm:p-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10">
            {/* Left Column: Image Gallery */}
            <div className="lg:col-span-6 space-y-4">
              <div className="relative aspect-[4/3] bg-slate-50 rounded-xl border border-slate-200 overflow-hidden flex items-center justify-center p-4">
                <img
                  src={selectedProduct.images[activeImageIndex] || selectedProduct.images[0]}
                  alt={selectedProduct.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-contain mix-blend-multiply"
                />
                {selectedProduct.discountPercent > 0 && (
                  <div className="absolute top-3 left-3 bg-red-600 text-white font-bold text-xs px-2.5 py-1 rounded-sm">
                    {selectedProduct.discountPercent}% OFF
                  </div>
                )}
              </div>

              {/* Thumbnail Strip */}
              {selectedProduct.images.length > 1 && (
                <div className="flex items-center gap-3 overflow-x-auto pb-1">
                  {selectedProduct.images.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActiveImageIndex(idx)}
                      className={`w-20 h-16 rounded-lg border-2 p-1 bg-slate-50 overflow-hidden transition-all shrink-0 cursor-pointer ${
                        activeImageIndex === idx
                          ? 'border-slate-900 shadow-xs'
                          : 'border-slate-200 hover:border-slate-400'
                      }`}
                    >
                      <img
                        src={img}
                        alt=""
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-contain mix-blend-multiply"
                      />
                    </button>
                  ))}
                </div>
              )}

              {/* Alibaba-style Trade Assurance & Protection Box */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5 text-xs text-slate-600">
                <div className="flex items-center gap-2 font-bold text-slate-900 text-sm">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Gadgethub Trade Assurance</span>
                </div>
                <div className="grid grid-cols-2 gap-2 pt-1 text-xs">
                  <div>
                    <span className="font-semibold text-slate-800 block">PTA Status:</span>
                    <span>100% Tax-Paid Official</span>
                  </div>
                  <div>
                    <span className="font-semibold text-slate-800 block">Warranty:</span>
                    <span>{selectedProduct.warranty}</span>
                  </div>
                  <div>
                    <span className="font-semibold text-slate-800 block">Payment:</span>
                    <span>Cash on Delivery (COD)</span>
                  </div>
                  <div>
                    <span className="font-semibold text-slate-800 block">Dispatch:</span>
                    <span>Within 24 Hours Sealed</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column: Contiguous Purchase Module */}
            <div className="lg:col-span-6 space-y-6">
              <div>
                <h1 className="text-xl sm:text-2xl font-black text-slate-900 leading-snug">
                  {selectedProduct.title}
                </h1>

                {/* Rating & In-Stock Status */}
                <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-xs text-slate-500 mt-2">
                  <div className="flex items-center text-amber-500">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-4 h-4 ${
                          i < Math.floor(selectedProduct.rating)
                            ? 'fill-current text-amber-500'
                            : 'text-slate-300'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="font-bold text-slate-900 tabular-nums">
                    {selectedProduct.rating.toFixed(1)}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="text-slate-500">{selectedProduct.reviewCount} customer reviews</span>
                  <span aria-hidden="true">·</span>
                  <span
                    className={
                      selectedProduct.stock > 0
                        ? 'text-emerald-700 font-semibold'
                        : 'text-red-600 font-semibold'
                    }
                  >
                    {selectedProduct.stock > 0
                      ? `${selectedProduct.stock} units available`
                      : 'Currently out of stock'}
                  </span>
                </div>
              </div>

              {/* Pricing & Alibaba-Style Wholesale Tiers */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <div className="flex items-baseline gap-3">
                  <span className="text-3xl font-black text-slate-900 tabular-nums">
                    Rs. {effectiveWholesale.toLocaleString()}
                  </span>
                  {selectedProduct.originalPrice > selectedProduct.price && (
                    <span className="text-sm text-slate-400 line-through tabular-nums">
                      Rs. {selectedProduct.originalPrice.toLocaleString()}
                    </span>
                  )}
                  {selectedProduct.discountPercent > 0 && (
                    <span className="text-xs font-bold text-red-600">
                      Save {selectedProduct.discountPercent}%
                    </span>
                  )}
                </div>

                {/* Wholesale Volume Discount Box */}
                {selectedProduct.wholesalePrice && (
                  <div className="mt-3 pt-3 border-t border-slate-200 text-xs">
                    <span className="font-semibold text-slate-800 block mb-1">
                      Wholesale / Bulk Tier Discount:
                    </span>
                    <div className="grid grid-cols-2 gap-2">
                      <div
                        className={`p-2 rounded-md border text-center ${
                          quantity < 3
                            ? 'border-slate-900 bg-white font-bold text-slate-900'
                            : 'border-slate-200 text-slate-600'
                        }`}
                      >
                        <div>1 – 2 Units</div>
                        <div className="font-mono text-slate-900">
                          Rs. {selectedProduct.price.toLocaleString()}
                        </div>
                      </div>
                      <div
                        className={`p-2 rounded-md border text-center ${
                          quantity >= 3
                            ? 'border-emerald-600 bg-emerald-50 font-bold text-emerald-900'
                            : 'border-slate-200 text-slate-600'
                        }`}
                      >
                        <div>3+ Units (Wholesale)</div>
                        <div className="font-mono text-emerald-700 font-bold">
                          Rs. {selectedProduct.wholesalePrice.toLocaleString()}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Description */}
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Product Overview
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {selectedProduct.description}
                </p>
              </div>

              {/* Pakistan City Delivery Calculator */}
              <div className="p-3.5 rounded-xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 font-bold text-slate-800">
                    <Truck className="w-4 h-4 text-amber-600" />
                    <span>Check Delivery to Your City</span>
                  </div>
                  <select
                    value={selectedCity}
                    onChange={(e) => setSelectedCity(e.target.value)}
                    className="bg-slate-100 text-xs font-medium py-1 px-2.5 rounded-md text-slate-800 focus:outline-none cursor-pointer"
                  >
                    {PAKISTAN_CITIES.map((city) => (
                      <option key={city} value={city}>
                        {city}
                      </option>
                    ))}
                  </select>
                </div>
                <p className="text-xs text-slate-600">
                  <span className="font-semibold text-slate-900">{getDeliveryEstimate(selectedCity)}</span>
                  . Cash on Delivery is available for all addresses in {selectedCity}.
                </p>
              </div>

              {/* Quantity Stepper & CTAs */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center gap-4">
                  <div className="flex items-center border border-slate-300 rounded-lg overflow-hidden bg-white">
                    <button
                      onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                      disabled={quantity <= 1}
                      className="px-3.5 py-2 text-slate-700 hover:bg-slate-100 transition-colors disabled:opacity-40 cursor-pointer"
                    >
                      -
                    </button>
                    <span className="px-4 py-2 text-xs font-bold font-mono tabular-nums text-slate-900">
                      {quantity}
                    </span>
                    <button
                      onClick={() =>
                        setQuantity((q) => Math.min(selectedProduct.stock, q + 1))
                      }
                      disabled={quantity >= selectedProduct.stock}
                      className="px-3.5 py-2 text-slate-700 hover:bg-slate-100 transition-colors disabled:opacity-40 cursor-pointer"
                    >
                      +
                    </button>
                  </div>

                  <span className="text-xs text-slate-500">
                    Total: <strong className="text-slate-900 font-mono">Rs. {(effectiveWholesale * quantity).toLocaleString()}</strong>
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <button
                    onClick={handleAddToCart}
                    disabled={selectedProduct.stock <= 0}
                    className={`w-full py-3 px-4 rounded-lg text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
                      addedNotice
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-900 hover:bg-slate-800 text-white shadow-xs'
                    }`}
                  >
                    {addedNotice ? (
                      <>
                        <Check className="w-4 h-4" />
                        <span>Added to Cart</span>
                      </>
                    ) : (
                      <>
                        <ShoppingBag className="w-4 h-4" />
                        <span>Add to Cart</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={handleBuyNow}
                    disabled={selectedProduct.stock <= 0}
                    className="w-full py-3 px-4 rounded-lg text-xs sm:text-sm font-bold bg-amber-500 hover:bg-amber-600 text-slate-950 transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-xs"
                  >
                    <Zap className="w-4 h-4" />
                    <span>Instant Checkout (COD)</span>
                  </button>
                </div>

                {/* Secondary Wishlist & Share buttons */}
                <div className="flex items-center justify-between pt-2 text-xs text-slate-500">
                  <button
                    onClick={() => toggleWishlist(selectedProduct.id)}
                    className="hover:text-slate-900 flex items-center gap-1.5 cursor-pointer py-1"
                  >
                    <Heart
                      className={`w-4 h-4 ${
                        isWish ? 'fill-current text-red-600' : 'text-slate-400'
                      }`}
                    />
                    <span>{isWish ? 'Saved in Wishlist' : 'Add to Wishlist'}</span>
                  </button>

                  <button
                    onClick={handleShare}
                    className="hover:text-slate-900 flex items-center gap-1.5 cursor-pointer py-1"
                  >
                    <Share2 className="w-4 h-4 text-slate-400" />
                    <span>{copiedShare ? 'Link Copied!' : 'Share Product'}</span>
                  </button>
                </div>
              </div>

              {/* Technical Specifications Table */}
              {Object.keys(selectedProduct.specs || {}).length > 0 && (
                <div className="pt-4 border-t border-slate-200">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-3">
                    Technical Specifications
                  </h3>
                  <div className="border border-slate-200 rounded-lg overflow-hidden text-xs">
                    {Object.entries(selectedProduct.specs).map(([specKey, specVal], idx) => (
                      <div
                        key={specKey}
                        className={`grid grid-cols-3 py-2 px-3 ${
                          idx % 2 === 0 ? 'bg-slate-50' : 'bg-white'
                        }`}
                      >
                        <span className="font-semibold text-slate-700 col-span-1">{specKey}</span>
                        <span className="text-slate-600 col-span-2 font-mono">{specVal}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
