import React, { useState } from 'react';
import { Search, ShoppingBag, Heart, ShieldCheck, Truck, Lock, User, Menu, X, ArrowRight, Check } from 'lucide-react';
import { useStore } from '../context/StoreContext';

interface HeaderProps {
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onOpenTracking: () => void;
  onOpenAdmin: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenCart,
  onOpenWishlist,
  onOpenTracking,
  onOpenAdmin,
}) => {
  const {
    cartTotalCount,
    wishlist,
    filters,
    setFilters,
    categories,
    isAdmin,
  } = useStore();

  const [searchInput, setSearchInput] = useState(filters.searchQuery);
  const [selectedCategory, setSelectedCategory] = useState(filters.categoryId);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFilters((prev) => ({
      ...prev,
      searchQuery: searchInput,
      categoryId: selectedCategory,
    }));
    // Smooth scroll down to products section
    const target = document.getElementById('products-section');
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleCategorySelect = (catId: string) => {
    setSelectedCategory(catId);
    setFilters((prev) => ({
      ...prev,
      categoryId: catId,
    }));
    const target = document.getElementById('products-section');
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200">
      {/* Top Notice Bar */}
      <div className="bg-slate-900 text-slate-300 text-xs py-2 px-4">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            <span className="font-semibold text-white tracking-wide">🇵🇰 PAKISTAN OFFICIAL STORE</span>
            <span className="text-slate-500">|</span>
            <span className="text-slate-300">Cash on Delivery (COD) Nationwide</span>
            <span className="hidden sm:inline text-slate-500">·</span>
            <span className="hidden sm:inline text-slate-300">Free delivery over Rs. 5,000</span>
          </div>
          <div className="flex items-center gap-4 text-xs">
            <button
              onClick={onOpenTracking}
              className="hover:text-white transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Truck className="w-3.5 h-3.5 text-amber-400" />
              <span>Track My Order</span>
            </button>
            <span className="text-slate-700">|</span>
            <div className="flex items-center gap-1.5 text-slate-400">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>PTA Approved & Verified</span>
            </div>
          </div>
        </div>
      </div>

      {/* Primary Top Bar Contract: Brand — Nav Links — Action */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex items-center justify-between gap-6 md:gap-8">
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-1.5 text-slate-700 hover:text-slate-900"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
          <a
            href="/"
            onClick={(e) => {
              e.preventDefault();
              setFilters((prev) => ({ ...prev, searchQuery: '', categoryId: 'all' }));
              setSearchInput('');
              setSelectedCategory('all');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="text-2xl font-black tracking-tight text-slate-900 whitespace-nowrap group flex items-center gap-1"
          >
            <span>Gadget</span>
            <span className="text-amber-600">hub</span>
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-500 mb-1 ml-0.5"></span>
          </a>
        </div>

        {/* Zone 2: Alibaba-style Search Bar & Quick Navigation */}
        <form
          onSubmit={handleSearchSubmit}
          className="hidden md:flex flex-1 max-w-2xl items-center border border-slate-300 hover:border-slate-400 focus-within:border-slate-900 transition-colors bg-white rounded-lg overflow-hidden shadow-xs"
        >
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="bg-slate-50 border-r border-slate-200 text-xs font-medium text-slate-700 py-2.5 px-3 focus:outline-none cursor-pointer"
          >
            <option value="all">All Categories</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
          <div className="relative flex-1 flex items-center">
            <Search className="w-4 h-4 text-slate-400 ml-3 shrink-0" />
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Search smartphones, ANC headphones, laptops, GaN chargers..."
              className="w-full py-2.5 px-3 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none"
            />
            {searchInput && (
              <button
                type="button"
                onClick={() => setSearchInput('')}
                className="p-1 mr-2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
          <button
            type="submit"
            className="bg-slate-900 hover:bg-slate-800 text-white font-medium text-xs py-3 px-5 transition-colors shrink-0 cursor-pointer flex items-center gap-1.5"
          >
            <span>Search</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </form>

        {/* Zone 3: Actions & Shopping Bag */}
        <div className="flex items-center gap-3 sm:gap-4 shrink-0">
          {/* Wishlist Button */}
          <button
            onClick={onOpenWishlist}
            className="relative p-2 text-slate-700 hover:text-slate-900 transition-colors cursor-pointer"
            title="Wishlist"
            aria-label="Wishlist"
          >
            <Heart className="w-5 h-5" />
            {wishlist.length > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-red-600 text-white text-[10px] font-bold flex items-center justify-center">
                {wishlist.length}
              </span>
            )}
          </button>

          {/* Cart Drawer Trigger */}
          <button
            onClick={onOpenCart}
            className="flex items-center gap-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold py-2.5 px-3.5 sm:px-4 rounded-lg transition-colors cursor-pointer shadow-xs"
            aria-label="Open Cart"
          >
            <div className="relative">
              <ShoppingBag className="w-4 h-4" />
              {cartTotalCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-amber-500 text-slate-950 font-black text-[10px] rounded-full w-4 h-4 flex items-center justify-center">
                  {cartTotalCount}
                </span>
              )}
            </div>
            <span className="hidden sm:inline whitespace-nowrap">Cart</span>
          </button>

          {/* Admin Portal Button */}
          <button
            onClick={onOpenAdmin}
            className={`flex items-center gap-1.5 text-xs font-medium py-2 px-2.5 rounded-md transition-colors cursor-pointer border ${
              isAdmin
                ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                : 'bg-white border-slate-200 text-slate-600 hover:text-slate-900 hover:border-slate-300'
            }`}
            title="Store Admin Panel"
          >
            <Lock className="w-3.5 h-3.5" />
            <span className="hidden md:inline">{isAdmin ? 'Admin (Active)' : 'Admin'}</span>
          </button>
        </div>
      </div>

      {/* Mobile Search Bar Row */}
      <div className="md:hidden px-4 pb-3">
        <form onSubmit={handleSearchSubmit} className="flex items-center border border-slate-300 rounded-lg overflow-hidden bg-white">
          <input
            type="text"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Search phones, tech, gadgets..."
            className="flex-1 py-2 px-3 text-sm focus:outline-none"
          />
          <button type="submit" className="bg-slate-900 text-white p-2.5">
            <Search className="w-4 h-4" />
          </button>
        </form>
      </div>

      {/* Secondary Category Navigation Strip (Alibaba-inspired) */}
      <div className="bg-slate-50 border-t border-slate-200 overflow-x-auto no-scrollbar">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2 flex items-center gap-6 text-xs text-slate-600 whitespace-nowrap font-medium">
          <button
            onClick={() => handleCategorySelect('all')}
            className={`transition-colors py-1 cursor-pointer ${
              filters.categoryId === 'all'
                ? 'text-slate-950 font-bold border-b-2 border-slate-950'
                : 'hover:text-slate-900'
            }`}
          >
            All Products
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => handleCategorySelect(cat.id)}
              className={`transition-colors py-1 cursor-pointer ${
                filters.categoryId === cat.id
                  ? 'text-slate-950 font-bold border-b-2 border-slate-950'
                  : 'hover:text-slate-900'
              }`}
            >
              {cat.name}
            </button>
          ))}
          <span className="text-slate-300">|</span>
          <button
            onClick={onOpenTracking}
            className="text-amber-800 hover:text-amber-950 font-semibold cursor-pointer"
          >
            Track COD Order
          </button>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed inset-0 top-[110px] z-50 bg-slate-950/60 backdrop-blur-xs flex flex-col">
          <div className="bg-white p-5 border-b border-slate-200 space-y-4 max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-center pb-2 border-b border-slate-100">
              <span className="font-bold text-sm text-slate-900">Browse Categories</span>
              <button onClick={() => setMobileMenuOpen(false)} className="text-slate-500">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  handleCategorySelect('all');
                  setMobileMenuOpen(false);
                }}
                className="text-left p-2.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-800 hover:bg-slate-50"
              >
                All Departments
              </button>
              {categories.map((c) => (
                <button
                  key={c.id}
                  onClick={() => {
                    handleCategorySelect(c.id);
                    setMobileMenuOpen(false);
                  }}
                  className="text-left p-2.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-50"
                >
                  {c.name}
                </button>
              ))}
            </div>

            <div className="pt-3 border-t border-slate-100 space-y-2">
              <button
                onClick={() => {
                  onOpenTracking();
                  setMobileMenuOpen(false);
                }}
                className="w-full text-left py-2 text-xs font-medium text-slate-700 flex items-center gap-2"
              >
                <Truck className="w-4 h-4 text-amber-500" />
                <span>Track Pakistan Courier Order</span>
              </button>
              <button
                onClick={() => {
                  onOpenAdmin();
                  setMobileMenuOpen(false);
                }}
                className="w-full text-left py-2 text-xs font-medium text-slate-700 flex items-center gap-2"
              >
                <Lock className="w-4 h-4 text-slate-500" />
                <span>Store Owner Admin Panel</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
