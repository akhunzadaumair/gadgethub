import React, { useState, useEffect } from 'react';
import {
  X,
  Lock,
  Plus,
  Trash2,
  Edit2,
  Package,
  ShoppingBag,
  TrendingUp,
  AlertTriangle,
  RotateCcw,
  Download,
  LogOut,
  Save,
  Check,
  Upload,
  Database,
  Image as ImageIcon,
  Copy,
  ExternalLink,
  FileCode,
  ShieldCheck,
  Mail,
  MessageSquare,
  RefreshCw,
  Eye,
  EyeOff,
  ArrowLeft,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { Product, OrderStatus } from '../types';

interface AdminModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AdminModal: React.FC<AdminModalProps> = ({ isOpen, onClose }) => {
  const {
    isAdmin,
    loginAdmin,
    logoutAdmin,
    adminPasswordError,
    products,
    categories,
    orders,
    addProduct,
    updateProduct,
    deleteProduct,
    updateOrderStatus,
    deleteOrder,
    uploadImage,
    resetAllData,
    retryNotification,
    syncCatalogWithSupabase,
    refreshOrders,
  } = useStore();

  const [passwordInput, setPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [activeTab, setActiveTab] = useState<'products' | 'orders' | 'settings'>('products');
  const [orderFilter, setOrderFilter] = useState<string>('all');
  const [productSearch, setProductSearch] = useState('');
  const [retryingOrderIds, setRetryingOrderIds] = useState<Record<string, boolean>>({});
  const [isSyncingCatalog, setIsSyncingCatalog] = useState(false);
  const [syncFeedback, setSyncFeedback] = useState<string | null>(null);
  const [confirmDeleteOrderId, setConfirmDeleteOrderId] = useState<string | null>(null);

  // Admin server auth status
  const [authStatus, setAuthStatus] = useState<{ configured: boolean; error: string | null } | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Add / Edit Product state
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const [saveSuccessNotice, setSaveSuccessNotice] = useState<string | null>(null);
  const [dbStatus, setDbStatus] = useState<any>(null);
  const [copiedSql, setCopiedSql] = useState(false);
  const [schemaCode, setSchemaCode] = useState<string>('');

  useEffect(() => {
    if (isOpen && !isAdmin) {
      fetch('/api/admin/auth-status')
        .then((r) => r.json())
        .then((data) => setAuthStatus({ configured: data.configured, error: data.error }))
        .catch(() => {
          setAuthStatus({
            configured: false,
            error: 'Unable to connect to authorization service.',
          });
        });
    }
  }, [isOpen, isAdmin]);

  useEffect(() => {
    if (activeTab === 'settings') {
      fetch('/api/health')
        .then((r) => r.json())
        .then((d) => setDbStatus(d.database))
        .catch(() => {});

      fetch('/api/schema')
        .then((r) => r.text())
        .then((t) => setSchemaCode(t))
        .catch(() => {});
    }
  }, [activeTab]);

  const handleCopySql = async () => {
    try {
      let textToCopy = schemaCode;
      if (!textToCopy) {
        const res = await fetch('/api/schema');
        textToCopy = await res.text();
        setSchemaCode(textToCopy);
      }
      await navigator.clipboard.writeText(textToCopy);
      setCopiedSql(true);
      setTimeout(() => setCopiedSql(false), 2500);
    } catch (err) {
      console.error('Failed copying SQL', err);
    }
  };

  const handleDownloadSql = async () => {
    try {
      let content = schemaCode;
      if (!content) {
        const res = await fetch('/api/schema');
        content = await res.text();
        setSchemaCode(content);
      }
      const blob = new Blob([content], { type: 'application/sql;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'schema.sql';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed downloading schema.sql via blob, redirecting:', err);
      window.location.href = '/api/schema/download';
    }
  };

  const handleRetryNotification = async (orderId: string, channel: 'all' | 'email' | 'whatsapp' = 'all') => {
    setRetryingOrderIds((prev) => ({ ...prev, [orderId]: true }));
    try {
      const res = await retryNotification(orderId, channel);
      if (res.success) {
        setSyncFeedback(`Notification alert re-sent successfully for ${orderId}`);
      } else {
        setSyncFeedback(`Retry failed: ${res.error}`);
      }
      setTimeout(() => setSyncFeedback(null), 4000);
    } finally {
      setRetryingOrderIds((prev) => ({ ...prev, [orderId]: false }));
    }
  };

  const handleSyncCatalog = async () => {
    setIsSyncingCatalog(true);
    setSyncFeedback(null);
    try {
      await syncCatalogWithSupabase();
      setSyncFeedback('Catalog and orders successfully synchronized from Supabase.');
      // Refresh DB status card
      const healthRes = await fetch('/api/health');
      if (healthRes.ok) {
        const d = await healthRes.json();
        setDbStatus(d.database);
      }
      setTimeout(() => setSyncFeedback(null), 4000);
    } catch (err: any) {
      setSyncFeedback(`Sync failed: ${err?.message || 'Network error'}`);
    } finally {
      setIsSyncingCatalog(false);
    }
  };

  const [formData, setFormData] = useState({
    title: '',
    category: 'Mobile Phones',
    categoryId: 'mobiles',
    brand: '',
    price: 0,
    originalPrice: 0,
    discountPercent: 0,
    stock: 10,
    images: '',
    description: '',
    warranty: '1 Year Brand Warranty',
    sku: '',
    moq: 1,
    wholesalePrice: 0,
  });

  if (!isOpen) return null;

  // Handle Admin Login (Server Verified)
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!passwordInput.trim()) return;
    setIsLoggingIn(true);
    await loginAdmin(passwordInput.trim());
    setIsLoggingIn(false);
  };

  // KPI calculations based strictly on real state
  const totalRevenue = orders
    .filter((o) => o.status !== 'Cancelled')
    .reduce((sum, o) => sum + o.total, 0);
  const lowStockCount = products.filter((p) => p.stock < 10).length;

  const handleOpenAdd = () => {
    setEditingProduct(null);
    setFormData({
      title: '',
      category: categories[0]?.name || 'Mobile Phones',
      categoryId: categories[0]?.id || 'mobiles',
      brand: '',
      price: 15000,
      originalPrice: 18000,
      discountPercent: 16,
      stock: 20,
      images: 'https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?auto=format&fit=crop&w=800&q=80',
      description: 'High-performance authentic gadget with Pakistan PTA approval and official brand warranty.',
      warranty: '1 Year Official Warranty',
      sku: `GH-${Math.floor(1000 + Math.random() * 9000)}`,
      moq: 1,
      wholesalePrice: 13500,
    });
    setIsAddingProduct(true);
  };

  const handleOpenEdit = (p: Product) => {
    setEditingProduct(p);
    setFormData({
      title: p.title,
      category: p.category,
      categoryId: p.categoryId,
      brand: p.brand,
      price: p.price,
      originalPrice: p.originalPrice,
      discountPercent: p.discountPercent,
      stock: p.stock,
      images: p.images.join(', '),
      description: p.description,
      warranty: p.warranty,
      sku: p.sku,
      moq: p.moq || 1,
      wholesalePrice: p.wholesalePrice || 0,
    });
    setIsAddingProduct(true);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingImage(true);
    try {
      const url = await uploadImage(file);
      setFormData((prev) => ({
        ...prev,
        images: prev.images ? `${url}, ${prev.images}` : url,
      }));
    } catch (err) {
      console.error('Image upload failed:', err);
    } finally {
      setIsUploadingImage(false);
    }
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    const imageList = formData.images
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    const calcDiscount =
      formData.originalPrice > formData.price
        ? Math.round(((formData.originalPrice - formData.price) / formData.originalPrice) * 100)
        : 0;

    if (editingProduct) {
      await updateProduct(editingProduct.id, {
        title: formData.title,
        category: formData.category,
        categoryId: formData.categoryId,
        brand: formData.brand,
        price: Number(formData.price),
        originalPrice: Number(formData.originalPrice),
        discountPercent: calcDiscount,
        stock: Number(formData.stock),
        images: imageList.length ? imageList : editingProduct.images,
        description: formData.description,
        warranty: formData.warranty,
        sku: formData.sku,
        moq: Number(formData.moq),
        wholesalePrice: Number(formData.wholesalePrice),
      });
      setSaveSuccessNotice(`Successfully updated "${formData.title}" in store database`);
    } else {
      await addProduct({
        title: formData.title,
        slug: formData.title.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
        category: formData.category,
        categoryId: formData.categoryId,
        brand: formData.brand,
        price: Number(formData.price),
        originalPrice: Number(formData.originalPrice),
        discountPercent: calcDiscount,
        stock: Number(formData.stock),
        rating: 5.0,
        reviewCount: 1,
        images: imageList.length ? imageList : ['https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?auto=format&fit=crop&w=800&q=80'],
        description: formData.description,
        specs: {
          'Brand': formData.brand,
          'Condition': 'Brand New Sealed',
          'Warranty': formData.warranty,
        },
        warranty: formData.warranty,
        sku: formData.sku,
        moq: Number(formData.moq),
        wholesalePrice: Number(formData.wholesalePrice),
        isFeatured: true,
        isTradeAssurance: true,
      });
      setSaveSuccessNotice(`Successfully added "${formData.title}" to store database`);
    }

    setTimeout(() => setSaveSuccessNotice(null), 3000);
    setIsAddingProduct(false);
    setEditingProduct(null);
  };

  const handleExportJSON = () => {
    const dataStr =
      'data:text/json;charset=utf-8,' +
      encodeURIComponent(JSON.stringify({ products, orders, categories }, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `gadgethub-export-${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/60 backdrop-blur-xs flex flex-col animate-in fade-in duration-150">
      <div
        className="relative bg-white w-full h-full flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="flex items-center justify-between px-4 sm:px-8 py-3.5 border-b border-slate-200 bg-slate-900 text-white shrink-0 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold tracking-tight text-white">
                  Gadgethub Merchant Console
                </h2>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-800/80">
                  Store Management Portal
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                Catalog Inventory, Live Orders & Customer Fulfillment
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            <button
              onClick={onClose}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors cursor-pointer border border-slate-700"
              title="Return to Customer Storefront"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Store</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              aria-label="Close"
              title="Close Admin Panel"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Auth Gate Check */}
        {!isAdmin ? (
          <div className="flex-1 overflow-y-auto flex items-center justify-center p-4 sm:p-6 bg-slate-50">
            <div className="w-full max-w-md bg-white p-8 sm:p-10 rounded-2xl shadow-xl border border-slate-200 text-center space-y-4">
              <div className="w-14 h-14 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-700">
                <Lock className="w-7 h-7" />
              </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">Store Owner Authorization</h3>
              <p className="text-xs text-slate-500 mt-1">
                Enter your administrative password to manage products, catalog pricing, orders, and delivery statuses.
              </p>
            </div>

            {/* Environment Variable Configuration Status Banner */}
            {authStatus && !authStatus.configured ? (
              <div className="p-3.5 bg-amber-50 border border-amber-200 text-amber-900 rounded-xl text-xs flex items-start gap-2.5 text-left">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <div className="font-bold text-amber-950">Configuration Required:</div>
                  <div className="text-amber-800 leading-relaxed text-[11px]">
                    {authStatus.error || 'The ADMIN_PASSWORD environment variable is not configured on the server. Please set ADMIN_PASSWORD in your environment to enable admin login.'}
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-2.5 bg-slate-50 border border-slate-200 text-slate-700 rounded-xl text-xs flex items-center justify-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span className="font-medium text-[11px]">
                  Protected by server-side <code className="bg-slate-200/80 px-1.5 py-0.5 rounded font-mono text-slate-800 font-bold">ADMIN_PASSWORD</code>
                </span>
              </div>
            )}

            <form onSubmit={handleLogin} className="space-y-3 pt-1">
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  placeholder="Enter configured ADMIN_PASSWORD"
                  disabled={isLoggingIn}
                  className="w-full py-2.5 pl-3 pr-10 text-xs bg-white border border-slate-300 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-slate-900 focus:ring-1 focus:ring-slate-900"
                  autoFocus
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((prev) => !prev)}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors cursor-pointer p-0.5"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {adminPasswordError && (
                <div className="p-2.5 bg-red-50 border border-red-200 text-red-700 rounded-lg text-xs font-medium text-left flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                  <span className="leading-snug">{adminPasswordError}</span>
                </div>
              )}
              <button
                type="submit"
                disabled={isLoggingIn || !passwordInput.trim()}
                className="w-full bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-bold text-xs py-2.5 px-4 rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-2"
              >
                {isLoggingIn ? (
                  <>
                    <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Authenticating...</span>
                  </>
                ) : (
                  <span>Unlock Admin Console</span>
                )}
              </button>
            </form>

            <div className="text-[11px] text-slate-400 pt-1 leading-relaxed">
              Authentication is validated securely on the server against the <code className="bg-slate-100 px-1 py-0.5 rounded font-mono text-slate-700 font-semibold">ADMIN_PASSWORD</code> environment variable.
            </div>
          </div>
        </div>
      ) : (
        /* Authenticated Admin Dashboard */
        <div className="flex-1 overflow-y-auto flex flex-col bg-slate-50">
          {/* KPI Summary Banner */}
          <div className="bg-white border-b border-slate-200 shrink-0">
            <div className="max-w-7xl mx-auto p-4 sm:p-6 grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
                  Total Revenue
                </span>
                <span className="text-base sm:text-xl font-black text-slate-900 tabular-nums font-mono">
                  Rs. {totalRevenue.toLocaleString()}
                </span>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
                  Total Orders
                </span>
                <span className="text-base sm:text-xl font-black text-slate-900 tabular-nums font-mono">
                  {orders.length}
                </span>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
                  Catalog Products
                </span>
                <span className="text-base sm:text-xl font-black text-slate-900 tabular-nums font-mono">
                  {products.length}
                </span>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
                  Low Stock Alert
                </span>
                <span className="text-base sm:text-xl font-black text-amber-700 tabular-nums font-mono">
                  {lowStockCount} items &lt; 10
                </span>
              </div>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="bg-white border-b border-slate-200 shrink-0 shadow-xs">
            <div className="max-w-7xl mx-auto flex items-center justify-between px-4 sm:px-8">
              <div className="flex gap-6 text-xs font-semibold">
                <button
                  onClick={() => {
                    setActiveTab('products');
                    setIsAddingProduct(false);
                  }}
                  className={`py-3.5 border-b-2 transition-colors cursor-pointer ${
                    activeTab === 'products'
                      ? 'border-slate-900 text-slate-900 font-bold'
                      : 'border-transparent text-slate-500 hover:text-slate-900'
                  }`}
                >
                  Products ({products.length})
                </button>
                <button
                  onClick={() => {
                    setActiveTab('orders');
                    setIsAddingProduct(false);
                  }}
                  className={`py-3.5 border-b-2 transition-colors cursor-pointer ${
                    activeTab === 'orders'
                      ? 'border-slate-900 text-slate-900 font-bold'
                      : 'border-transparent text-slate-500 hover:text-slate-900'
                  }`}
                >
                  Customer Orders ({orders.length})
                </button>
                <button
                  onClick={() => {
                    setActiveTab('settings');
                    setIsAddingProduct(false);
                  }}
                  className={`py-3.5 border-b-2 transition-colors cursor-pointer ${
                    activeTab === 'settings'
                      ? 'border-slate-900 text-slate-900 font-bold'
                      : 'border-transparent text-slate-500 hover:text-slate-900'
                  }`}
                >
                  Database & Export
                </button>
              </div>

              <button
                onClick={logoutAdmin}
                className="text-xs text-red-600 hover:text-red-700 font-semibold flex items-center gap-1.5 cursor-pointer py-1.5 px-3 rounded-lg hover:bg-red-50 transition-colors border border-transparent hover:border-red-200"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            </div>
          </div>

          {/* Tab Contents */}
          <div className="p-4 sm:p-8 flex-1 overflow-y-auto">
            <div className="max-w-7xl mx-auto">
              {/* TAB 1: PRODUCTS */}
              {activeTab === 'products' && (
                <div className="space-y-4">
                  {saveSuccessNotice && (
                    <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>{saveSuccessNotice}</span>
                    </div>
                  )}

                  {!isAddingProduct ? (
                    <>
                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                        <input
                          type="text"
                          value={productSearch}
                          onChange={(e) => setProductSearch(e.target.value)}
                          placeholder="Search product inventory by title or SKU..."
                          className="w-full sm:w-72 py-2 px-3 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-slate-900"
                        />
                        <button
                          onClick={handleOpenAdd}
                          className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs py-2 px-4 rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs shrink-0"
                        >
                          <Plus className="w-4 h-4" />
                          <span>Add New Product</span>
                        </button>
                      </div>

                      {/* Products Table */}
                      <div className="border border-slate-200 rounded-xl overflow-hidden">
                        <table className="w-full text-left text-xs">
                          <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                            <tr>
                              <th className="py-2.5 px-3">Product</th>
                              <th className="py-2.5 px-3">Category</th>
                              <th className="py-2.5 px-3 text-right">Price (PKR)</th>
                              <th className="py-2.5 px-3 text-right">Stock</th>
                              <th className="py-2.5 px-3 text-center">Actions</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                            {products
                              .filter((p) =>
                                p.title.toLowerCase().includes(productSearch.toLowerCase()) ||
                                p.sku.toLowerCase().includes(productSearch.toLowerCase())
                              )
                              .map((p) => (
                                <tr key={p.id} className="hover:bg-slate-50/70 transition-colors">
                                  <td className="py-2.5 px-3">
                                    <div className="flex items-center gap-2.5">
                                      <img
                                        src={p.images[0]}
                                        alt=""
                                        referrerPolicy="no-referrer"
                                        className="w-10 h-10 object-contain bg-white rounded border border-slate-200 p-0.5 shrink-0"
                                      />
                                      <div className="min-w-0">
                                        <div className="font-semibold text-slate-900 truncate max-w-xs">
                                          {p.title}
                                        </div>
                                        <div className="text-[10px] text-slate-400 font-mono">
                                          SKU: {p.sku} · {p.brand}
                                        </div>
                                      </div>
                                    </div>
                                  </td>
                                  <td className="py-2.5 px-3 text-slate-600">{p.category}</td>
                                  <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900 tabular-nums">
                                    Rs. {p.price.toLocaleString()}
                                  </td>
                                  <td className="py-2.5 px-3 text-right">
                                    <span
                                      className={`font-mono font-bold tabular-nums ${
                                        p.stock < 10 ? 'text-red-600' : 'text-slate-800'
                                      }`}
                                    >
                                      {p.stock}
                                    </span>
                                  </td>
                                  <td className="py-2.5 px-3 text-center">
                                    <div className="flex items-center justify-center gap-1.5">
                                      <button
                                        onClick={() => handleOpenEdit(p)}
                                        className="p-1 text-slate-500 hover:text-slate-900 transition-colors cursor-pointer"
                                        title="Edit Product"
                                      >
                                        <Edit2 className="w-3.5 h-3.5" />
                                      </button>
                                      <button
                                        onClick={() => {
                                          if (confirm(`Delete "${p.title}"?`)) {
                                            deleteProduct(p.id);
                                          }
                                        }}
                                        className="p-1 text-slate-400 hover:text-red-600 transition-colors cursor-pointer"
                                        title="Delete Product"
                                      >
                                        <Trash2 className="w-3.5 h-3.5" />
                                      </button>
                                    </div>
                                  </td>
                                </tr>
                              ))}
                          </tbody>
                        </table>
                      </div>
                    </>
                  ) : (
                    /* Add / Edit Form */
                    <form onSubmit={handleSaveProduct} className="space-y-4 max-w-2xl bg-slate-50 p-5 rounded-xl border border-slate-200">
                      <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                        <h4 className="font-bold text-slate-900 text-sm">
                          {editingProduct ? 'Edit Existing Product' : 'Add New Gadget to Store'}
                        </h4>
                        <button
                          type="button"
                          onClick={() => setIsAddingProduct(false)}
                          className="text-xs text-slate-500 hover:text-slate-800"
                        >
                          Cancel
                        </button>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                        <div className="sm:col-span-2">
                          <label className="block font-semibold text-slate-700 mb-1">
                            Product Title *
                          </label>
                          <input
                            type="text"
                            required
                            value={formData.title}
                            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                            className="w-full p-2 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900"
                          />
                        </div>

                        <div>
                          <label className="block font-semibold text-slate-700 mb-1">
                            Brand *
                          </label>
                          <input
                            type="text"
                            required
                            value={formData.brand}
                            onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                            className="w-full p-2 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900"
                          />
                        </div>

                        <div>
                          <label className="block font-semibold text-slate-700 mb-1">
                            Category *
                          </label>
                          <select
                            value={formData.categoryId}
                            onChange={(e) => {
                              const found = categories.find((c) => c.id === e.target.value);
                              setFormData({
                                ...formData,
                                categoryId: e.target.value,
                                category: found?.name || 'Mobile Phones',
                              });
                            }}
                            className="w-full p-2 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900"
                          >
                            {categories.map((c) => (
                              <option key={c.id} value={c.id}>
                                {c.name}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <label className="block font-semibold text-slate-700 mb-1">
                            Selling Price in PKR (Rs.) *
                          </label>
                          <input
                            type="number"
                            required
                            min="100"
                            value={formData.price}
                            onChange={(e) =>
                              setFormData({ ...formData, price: Number(e.target.value) })
                            }
                            className="w-full p-2 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900 font-mono"
                          />
                        </div>

                        <div>
                          <label className="block font-semibold text-slate-700 mb-1">
                            Original Strike Price (Rs.)
                          </label>
                          <input
                            type="number"
                            min="0"
                            value={formData.originalPrice}
                            onChange={(e) =>
                              setFormData({ ...formData, originalPrice: Number(e.target.value) })
                            }
                            className="w-full p-2 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900 font-mono"
                          />
                        </div>

                        <div>
                          <label className="block font-semibold text-slate-700 mb-1">
                            Stock Units *
                          </label>
                          <input
                            type="number"
                            required
                            min="0"
                            value={formData.stock}
                            onChange={(e) =>
                              setFormData({ ...formData, stock: Number(e.target.value) })
                            }
                            className="w-full p-2 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900 font-mono"
                          />
                        </div>

                        <div>
                          <label className="block font-semibold text-slate-700 mb-1">
                            SKU Identifier
                          </label>
                          <input
                            type="text"
                            value={formData.sku}
                            onChange={(e) => setFormData({ ...formData, sku: e.target.value })}
                            className="w-full p-2 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900 font-mono"
                          />
                        </div>

                        <div className="sm:col-span-2 space-y-2">
                          <div className="flex items-center justify-between">
                            <label className="block font-semibold text-slate-700">
                              Product Images (URLs or Upload) *
                            </label>
                            <label className="flex items-center gap-1.5 px-3 py-1 bg-white border border-slate-300 hover:border-slate-400 text-slate-700 rounded-md cursor-pointer text-xs font-semibold shadow-xs">
                              <Upload className="w-3.5 h-3.5 text-amber-600" />
                              <span>{isUploadingImage ? 'Uploading...' : 'Upload Device Image'}</span>
                              <input
                                type="file"
                                accept="image/*"
                                onChange={handleFileUpload}
                                disabled={isUploadingImage}
                                className="hidden"
                              />
                            </label>
                          </div>
                          <input
                            type="text"
                            required
                            value={formData.images}
                            onChange={(e) => setFormData({ ...formData, images: e.target.value })}
                            placeholder="Enter image URL or upload image file above"
                            className="w-full p-2 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900 text-xs"
                          />
                          {formData.images && (
                            <div className="flex flex-wrap gap-2 pt-1">
                              {formData.images.split(',').map((imgUrl, idx) => {
                                const clean = imgUrl.trim();
                                if (!clean) return null;
                                return (
                                  <div key={idx} className="relative w-14 h-14 rounded border border-slate-200 bg-white p-1 overflow-hidden group">
                                    <img
                                      src={clean}
                                      alt="Preview"
                                      className="w-full h-full object-contain"
                                    />
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const rest = formData.images
                                          .split(',')
                                          .map((s) => s.trim())
                                          .filter((_, i) => i !== idx)
                                          .join(', ');
                                        setFormData({ ...formData, images: rest });
                                      }}
                                      className="absolute inset-0 bg-red-600/80 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity text-[10px]"
                                    >
                                      Remove
                                    </button>
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </div>

                        <div className="sm:col-span-2">
                          <label className="block font-semibold text-slate-700 mb-1">
                            Description
                          </label>
                          <textarea
                            rows={3}
                            value={formData.description}
                            onChange={(e) =>
                              setFormData({ ...formData, description: e.target.value })
                            }
                            className="w-full p-2 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900"
                          />
                        </div>
                      </div>

                      <div className="flex justify-end gap-2 pt-2">
                        <button
                          type="button"
                          onClick={() => setIsAddingProduct(false)}
                          className="px-4 py-2 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-100"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                        >
                          <Save className="w-3.5 h-3.5" />
                          <span>Save Product</span>
                        </button>
                      </div>
                    </form>
                  )}
                </div>
              )}

              {/* TAB 2: ORDERS MANAGEMENT */}
              {activeTab === 'orders' && (
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-slate-700">Filter status:</span>
                      {['all', 'Pending', 'Confirmed', 'Processing', 'Shipped', 'Delivered', 'Cancelled'].map(
                        (st) => (
                          <button
                            key={st}
                            onClick={() => setOrderFilter(st)}
                            className={`px-2.5 py-1 rounded-md capitalize transition-colors cursor-pointer ${
                              orderFilter === st
                                ? 'bg-slate-900 text-white font-bold'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                            }`}
                          >
                            {st}
                          </button>
                        )
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={handleSyncCatalog}
                        disabled={isSyncingCatalog}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-300 hover:border-slate-400 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer shadow-xs disabled:opacity-50"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${isSyncingCatalog ? 'animate-spin text-blue-600' : ''}`} />
                        <span>{isSyncingCatalog ? 'Syncing...' : 'Sync Supabase Orders'}</span>
                      </button>
                    </div>
                  </div>

                  {syncFeedback && (
                    <div className="p-3 bg-blue-50 border border-blue-200 text-blue-900 rounded-lg text-xs flex items-center justify-between">
                      <span>{syncFeedback}</span>
                      <button onClick={() => setSyncFeedback(null)} className="text-blue-700 font-bold hover:underline">
                        Dismiss
                      </button>
                    </div>
                  )}

                  <div className="border border-slate-200 rounded-xl overflow-hidden">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                        <tr>
                          <th className="py-2.5 px-3">Order ID / Date</th>
                          <th className="py-2.5 px-3">Customer / City</th>
                          <th className="py-2.5 px-3">Items</th>
                          <th className="py-2.5 px-3">Payment</th>
                          <th className="py-2.5 px-3 text-right">Total (PKR)</th>
                          <th className="py-2.5 px-3 text-center">Store Alerts (Email & WhatsApp)</th>
                          <th className="py-2.5 px-3 text-center">Status Control</th>
                          <th className="py-2.5 px-3 text-center">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {orders
                          .filter((o) => (orderFilter === 'all' ? true : o.status === orderFilter))
                          .map((order) => {
                            const emailStatus = order.notifications?.email?.status || 'pending';
                            const whatsappStatus = order.notifications?.whatsapp?.status || 'pending';
                            const isRetrying = Boolean(retryingOrderIds[order.id]);

                            return (
                              <tr key={order.id} className="hover:bg-slate-50/70 transition-colors">
                                <td className="py-3 px-3">
                                  <div className="font-mono font-bold text-slate-900">{order.id}</div>
                                  <div className="text-[10px] text-slate-400">
                                    {new Date(order.date).toLocaleDateString()}
                                  </div>
                                </td>
                                <td className="py-3 px-3">
                                  <div className="font-semibold text-slate-800">
                                    {order.customer.fullName}
                                  </div>
                                  <div className="text-[11px] text-slate-500">
                                    {order.customer.city} · {order.customer.phone}
                                  </div>
                                </td>
                                <td className="py-3 px-3">
                                  <span className="font-semibold text-slate-700">
                                    {order.items.length} items
                                  </span>
                                </td>
                                <td className="py-3 px-3">
                                  <span className="uppercase text-[11px] font-mono font-bold text-slate-700">
                                    {order.paymentMethod}
                                  </span>
                                </td>
                                <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 tabular-nums">
                                  Rs. {order.total.toLocaleString()}
                                </td>

                                {/* Notification Badges & Retry Control */}
                                <td className="py-3 px-3">
                                  <div className="flex flex-col items-center gap-1.5">
                                    <div className="flex items-center gap-1.5 flex-wrap justify-center">
                                      {/* Email Badge */}
                                      <span
                                        title={
                                          order.notifications?.email?.error
                                            ? `Email Error: ${order.notifications.email.error}`
                                            : `Email: ${order.notifications?.email?.recipient || 'akhunzadaumair27@gmail.com'}`
                                        }
                                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                                          emailStatus === 'sent'
                                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                                            : emailStatus === 'failed'
                                            ? 'bg-red-100 text-red-800 border border-red-300'
                                            : emailStatus === 'not_configured'
                                            ? 'bg-amber-100 text-amber-800 border border-amber-300'
                                            : 'bg-slate-100 text-slate-700'
                                        }`}
                                      >
                                        <Mail className="w-3 h-3" />
                                        <span>
                                          {emailStatus === 'sent'
                                            ? 'Email Sent'
                                            : emailStatus === 'failed'
                                            ? 'Email Failed'
                                            : emailStatus === 'not_configured'
                                            ? 'Email No Key'
                                            : 'Email Pending'}
                                        </span>
                                      </span>

                                      {/* WhatsApp Badge */}
                                      <span
                                        title={
                                          order.notifications?.whatsapp?.error
                                            ? `WhatsApp Error: ${order.notifications.whatsapp.error}`
                                            : `WhatsApp: ${order.notifications?.whatsapp?.recipient || '+923293778337'}`
                                        }
                                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                                          whatsappStatus === 'sent'
                                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                                            : whatsappStatus === 'failed'
                                            ? 'bg-red-100 text-red-800 border border-red-300'
                                            : whatsappStatus === 'not_configured'
                                            ? 'bg-amber-100 text-amber-800 border border-amber-300'
                                            : 'bg-slate-100 text-slate-700'
                                        }`}
                                      >
                                        <MessageSquare className="w-3 h-3" />
                                        <span>
                                          {whatsappStatus === 'sent'
                                            ? 'WhatsApp Sent'
                                            : whatsappStatus === 'failed'
                                            ? 'WhatsApp Failed'
                                            : whatsappStatus === 'not_configured'
                                            ? 'WA No Token'
                                            : 'WA Pending'}
                                        </span>
                                      </span>
                                    </div>

                                    {/* Retry Notification Action */}
                                    <button
                                      type="button"
                                      onClick={() => handleRetryNotification(order.id, 'all')}
                                      disabled={isRetrying}
                                      className="inline-flex items-center gap-1 text-[10px] font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 px-2 py-0.5 rounded cursor-pointer transition-colors disabled:opacity-50"
                                      title="Re-send email and WhatsApp notifications to store owner"
                                    >
                                      <RotateCcw className={`w-3 h-3 ${isRetrying ? 'animate-spin text-blue-600' : ''}`} />
                                      <span>{isRetrying ? 'Sending...' : 'Retry Alerts'}</span>
                                    </button>
                                  </div>
                                </td>

                                <td className="py-3 px-3 text-center">
                                  <select
                                    value={order.status}
                                    onChange={(e) =>
                                      updateOrderStatus(order.id, e.target.value as OrderStatus)
                                    }
                                    className="text-xs py-1 px-2 rounded border border-slate-300 bg-white font-medium focus:outline-none focus:border-slate-900 cursor-pointer"
                                  >
                                    <option value="Pending">Pending</option>
                                    <option value="Confirmed">Confirmed</option>
                                    <option value="Processing">Processing</option>
                                    <option value="Shipped">Shipped</option>
                                    <option value="Delivered">Delivered</option>
                                    <option value="Cancelled">Cancelled</option>
                                  </select>
                                </td>

                                <td className="py-3 px-3 text-center">
                                  {confirmDeleteOrderId === order.id ? (
                                    <div className="flex items-center justify-center gap-1">
                                      <button
                                        type="button"
                                        onClick={async () => {
                                          await deleteOrder(order.id);
                                          setConfirmDeleteOrderId(null);
                                        }}
                                        className="px-2 py-0.5 bg-red-600 hover:bg-red-700 text-white rounded text-[10px] font-bold cursor-pointer transition-colors"
                                      >
                                        Delete
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => setConfirmDeleteOrderId(null)}
                                        className="px-1.5 py-0.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded text-[10px] cursor-pointer"
                                      >
                                        Cancel
                                      </button>
                                    </div>
                                  ) : (
                                    <button
                                      type="button"
                                      onClick={() => setConfirmDeleteOrderId(order.id)}
                                      className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
                                      title={`Delete order ${order.id}`}
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  )}
                                </td>
                              </tr>
                            );
                          })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB 3: SETTINGS & BACKUP */}
              {activeTab === 'settings' && (
                <div className="space-y-6 max-w-xl text-xs text-slate-600">
                  {/* Supabase & PostgreSQL Integration Card */}
                  <div className="p-4 rounded-xl border border-blue-200 bg-blue-50/50 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Database className="w-4 h-4 text-blue-700" />
                        <h4 className="font-bold text-slate-900 text-sm">
                          Database & Supabase Status
                        </h4>
                      </div>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-sm uppercase tracking-wider ${
                          dbStatus?.supabaseConnected
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                            : 'bg-amber-100 text-amber-800 border border-amber-300'
                        }`}
                      >
                        {dbStatus?.supabaseConnected ? 'Supabase Connected' : 'Local Persistent DB Active'}
                      </span>
                    </div>

                    <div className="p-2.5 bg-white rounded-lg border border-blue-100 text-[11px] space-y-1.5 text-slate-700">
                      <div>
                        <strong>Current Storage Engine:</strong>{' '}
                        <span className="font-mono text-slate-800">
                          {dbStatus?.storageType || 'Local Persistent JSON Engine'}
                        </span>
                      </div>
                      <div>
                        <strong>Supabase Cloud Connection:</strong>{' '}
                        <span className={dbStatus?.supabaseConnected ? 'text-emerald-700 font-bold' : 'text-amber-700 font-semibold'}>
                          {dbStatus?.supabaseStatus || 'Awaiting SUPABASE_URL and SUPABASE_KEY in .env'}
                        </span>
                      </div>
                      {dbStatus?.supabaseDetails && (
                        <div className="text-[10px] text-slate-500 pt-1 border-t border-slate-100 flex flex-wrap gap-x-4 gap-y-1">
                          <span>URL: <code className="text-slate-800">{dbStatus.supabaseDetails.url}</code></span>
                          <span>Service Role: <strong className={dbStatus.supabaseDetails.hasServiceRoleKey ? 'text-emerald-700' : 'text-amber-700'}>{dbStatus.supabaseDetails.hasServiceRoleKey ? 'Active (Full RLS Bypass)' : 'Standard / Anon Key'}</strong></span>
                          <span>Live Tables: <strong>{dbStatus.supabaseDetails.categoryCount} Categories · {dbStatus.supabaseDetails.productCount} Products</strong></span>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-2 pt-1">
                      <button
                        type="button"
                        onClick={handleSyncCatalog}
                        disabled={isSyncingCatalog}
                        className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-1.5 px-3 rounded-md flex items-center gap-1.5 text-xs transition-colors shadow-xs disabled:opacity-50 cursor-pointer"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${isSyncingCatalog ? 'animate-spin' : ''}`} />
                        <span>{isSyncingCatalog ? 'Synchronizing with Supabase...' : 'Synchronize Catalog from Supabase'}</span>
                      </button>
                    </div>

                  {/* Order Notifications Engine Status Card */}
                  <div className="p-4 rounded-xl border border-purple-200 bg-purple-50/50 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4 text-purple-700" />
                        <h4 className="font-bold text-slate-900 text-sm">
                          Store Owner Order Notifications
                        </h4>
                      </div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-sm uppercase tracking-wider bg-purple-100 text-purple-800 border border-purple-300">
                        Email & WhatsApp Engine
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {/* Email Status Box */}
                      <div className="p-3 bg-white rounded-lg border border-purple-100 text-[11px] space-y-1">
                        <div className="flex items-center justify-between font-bold text-slate-800">
                          <span className="flex items-center gap-1">
                            <Mail className="w-3.5 h-3.5 text-purple-600" />
                            <span>Email (Resend)</span>
                          </span>
                          <span className={`text-[10px] px-1.5 py-0.5 rounded ${dbStatus?.notifications?.email?.configured ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                            {dbStatus?.notifications?.email?.configured ? 'Ready' : 'Awaiting Key'}
                          </span>
                        </div>
                        <div className="text-slate-600 text-[10px]">
                          <strong>Recipient:</strong> {dbStatus?.notifications?.email?.recipient || 'akhunzadaumair27@gmail.com'}
                        </div>
                        <div className="text-slate-500 text-[10px]">
                          {dbStatus?.notifications?.email?.help || 'Configured via RESEND_API_KEY in .env'}
                        </div>
                      </div>

                      {/* WhatsApp Status Box */}
                      <div className="p-3 bg-white rounded-lg border border-purple-100 text-[11px] space-y-1">
                        <div className="flex items-center justify-between font-bold text-slate-800">
                          <span className="flex items-center gap-1">
                            <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                            <span>WhatsApp (Cloud API)</span>
                          </span>
                          <span className={`text-[10px] px-1.5 py-0.5 rounded ${dbStatus?.notifications?.whatsapp?.configured ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                            {dbStatus?.notifications?.whatsapp?.configured ? 'Ready' : 'Awaiting Token'}
                          </span>
                        </div>
                        <div className="text-slate-600 text-[10px]">
                          <strong>Recipient:</strong> {dbStatus?.notifications?.whatsapp?.recipient || '+923293778337'}
                        </div>
                        <div className="text-slate-500 text-[10px]">
                          {dbStatus?.notifications?.whatsapp?.help || 'Configured via WHATSAPP_ACCESS_TOKEN in .env'}
                        </div>
                      </div>
                    </div>
                  </div>

                    <div className="p-3 bg-white rounded-lg border border-blue-200 text-[11px] space-y-2.5">
                      <div className="font-bold text-slate-900 flex items-center justify-between">
                        <span>Database Setup Script (schema.sql):</span>
                        <span className="text-[10px] text-slate-500 font-normal">Location: /schema.sql</span>
                      </div>

                      <div className="flex flex-wrap items-center gap-2 pt-1">
                        <button
                          type="button"
                          onClick={handleDownloadSql}
                          className="bg-slate-900 hover:bg-slate-800 text-white font-bold py-1.5 px-3 rounded-md flex items-center gap-1.5 cursor-pointer text-xs transition-colors shadow-xs"
                          title="Download schema.sql file"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>Download SQL</span>
                        </button>

                        <button
                          type="button"
                          onClick={handleCopySql}
                          className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-1.5 px-3 rounded-md flex items-center gap-1.5 cursor-pointer text-xs transition-colors shadow-xs"
                        >
                          {copiedSql ? (
                            <>
                              <Check className="w-3.5 h-3.5" />
                              <span>Copied to Clipboard!</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              <span>Copy schema.sql</span>
                            </>
                          )}
                        </button>

                        <a
                          href="/api/schema/download"
                          download="schema.sql"
                          className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold py-1.5 px-3 rounded-md flex items-center gap-1.5 text-xs transition-colors border border-slate-300"
                          title="Direct server download"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>Direct Link</span>
                        </a>

                        <a
                          href="/schema.sql"
                          target="_blank"
                          rel="noreferrer"
                          className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold py-1.5 px-3 rounded-md flex items-center gap-1.5 text-xs transition-colors border border-slate-300"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                          <span>View in Browser</span>
                        </a>
                      </div>

                      <div className="pt-2 border-t border-slate-100 text-slate-600 space-y-1">
                        <div className="font-bold text-slate-800">Setup Steps for Supabase:</div>
                        <ol className="list-decimal list-inside space-y-1">
                          <li>Click <strong>Copy schema.sql</strong> above (or open <code>schema.sql</code> in the project root).</li>
                          <li>Go to your <strong>Supabase Dashboard</strong> &rarr; <strong>SQL Editor</strong> &rarr; <strong>+ New Query</strong>.</li>
                          <li>Paste the SQL and click <strong>Run</strong>.</li>
                          <li>Copy your <strong>Project URL</strong> and <strong>service_role</strong> API Key from <strong>Settings &rarr; API</strong>.</li>
                          <li>Add <code>SUPABASE_URL</code> and <code>SUPABASE_KEY</code> to your <code>.env</code> file, then restart the server.</li>
                        </ol>
                      </div>

                      {schemaCode && (
                        <details className="pt-1">
                          <summary className="font-semibold text-blue-700 cursor-pointer text-[11px] hover:underline">
                            Preview schema.sql script ({schemaCode.split('\n').length} lines)
                          </summary>
                          <pre className="mt-2 p-3 bg-slate-900 text-slate-100 rounded-lg text-[10px] font-mono max-h-52 overflow-y-auto overflow-x-auto whitespace-pre">
                            {schemaCode}
                          </pre>
                        </details>
                      )}
                    </div>
                  </div>

                  {/* Download Full Source Code ZIP Card */}
                  <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/50 space-y-2">
                    <div className="flex items-center gap-2">
                      <Download className="w-4 h-4 text-emerald-700" />
                      <h4 className="font-bold text-slate-900 text-sm">Download Complete Project (.ZIP)</h4>
                    </div>
                    <p className="text-slate-600">
                      Download the complete, self-contained project source code archive including all frontend components, styles, Express backend API, database schemas, and README setup guide.
                    </p>
                    <a
                      href="/api/download/zip"
                      download="gadgethub-source.zip"
                      className="inline-flex items-center gap-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-2 px-4 rounded-lg cursor-pointer transition-colors"
                    >
                      <Download className="w-4 h-4" />
                      <span>Download gadgethub-source.zip</span>
                    </a>
                  </div>

                  <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-2">
                    <h4 className="font-bold text-slate-900 text-sm">Export Store Catalog & Orders</h4>
                    <p>
                      Download full JSON dump of current products, stock levels, categories, and customer order history for backup or migration to Supabase/PostgreSQL.
                    </p>
                    <button
                      onClick={handleExportJSON}
                      className="bg-slate-900 hover:bg-slate-800 text-white font-bold py-2 px-4 rounded-lg flex items-center gap-1.5 cursor-pointer"
                    >
                      <Download className="w-4 h-4" />
                      <span>Export Database JSON</span>
                    </button>
                  </div>

                  <div className="p-4 rounded-xl border border-red-200 bg-red-50/50 space-y-2">
                    <h4 className="font-bold text-red-900 text-sm">Reset Store to Default Demo Data</h4>
                    <p className="text-red-700">
                      This will restore all default products, simulated orders, and purge the current cart/wishlist.
                    </p>
                    <button
                      onClick={() => {
                        if (confirm('Are you sure you want to restore default catalog and orders?')) {
                          resetAllData();
                          alert('Store database restored to initial sample data.');
                        }
                      }}
                      className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-lg flex items-center gap-1.5 cursor-pointer"
                    >
                      <RotateCcw className="w-4 h-4" />
                      <span>Reset Catalog Data</span>
                    </button>
                  </div>
                </div>
              )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
