import React from 'react';
import {
  Smartphone,
  Headphones,
  Watch,
  Laptop,
  Zap,
  Home,
  Gamepad2,
  Backpack,
  ArrowRight,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';

const ICON_MAP: Record<string, React.ReactNode> = {
  Smartphone: <Smartphone className="w-5 h-5" />,
  Headphones: <Headphones className="w-5 h-5" />,
  Watch: <Watch className="w-5 h-5" />,
  Laptop: <Laptop className="w-5 h-5" />,
  Zap: <Zap className="w-5 h-5" />,
  Home: <Home className="w-5 h-5" />,
  Gamepad2: <Gamepad2 className="w-5 h-5" />,
  Backpack: <Backpack className="w-5 h-5" />,
};

export const CategoryShowcase: React.FC = () => {
  const { categories, setFilters, filters } = useStore();

  const handleSelectCategory = (catId: string) => {
    setFilters((prev) => ({ ...prev, categoryId: catId }));
    const el = document.getElementById('products-section');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="py-8 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Departments & Niches
            </span>
            <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight">
              Featured Tech Categories
            </h2>
          </div>
          <button
            onClick={() => handleSelectCategory('all')}
            className="text-xs font-semibold text-amber-700 hover:text-amber-800 flex items-center gap-1 cursor-pointer"
          >
            <span>View All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          {categories.map((cat) => {
            const isSelected = filters.categoryId === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => handleSelectCategory(cat.id)}
                className={`p-3 rounded-xl border text-left transition-all duration-150 flex flex-col justify-between cursor-pointer group ${
                  isSelected
                    ? 'border-slate-900 bg-slate-50 shadow-xs'
                    : 'border-slate-200/90 hover:border-slate-300 hover:bg-slate-50/50'
                }`}
              >
                <div
                  className={`w-9 h-9 rounded-lg flex items-center justify-center transition-colors mb-2.5 ${
                    isSelected
                      ? 'bg-slate-900 text-white'
                      : 'bg-slate-100 text-slate-700 group-hover:bg-amber-100 group-hover:text-amber-800'
                  }`}
                >
                  {ICON_MAP[cat.iconName] || <Smartphone className="w-5 h-5" />}
                </div>

                <div>
                  <h3 className="text-xs font-bold text-slate-900 group-hover:text-amber-700 transition-colors line-clamp-1">
                    {cat.name}
                  </h3>
                  <span className="text-[10px] text-slate-400 mt-0.5 block">
                    {cat.itemCount} items
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
};
