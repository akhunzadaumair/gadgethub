import React, { useState } from 'react';
import { Heart, ShoppingBag, Star, ShieldCheck, Check } from 'lucide-react';
import { Product } from '../types';
import { useStore } from '../context/StoreContext';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart, isInWishlist, toggleWishlist, setSelectedProduct } = useStore();
  const [imageError, setImageError] = useState(false);
  const [addedJustNow, setAddedJustNow] = useState(false);

  const isWish = isInWishlist(product.id);

  const handleCardClick = () => {
    setSelectedProduct(product);
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, 1);
    setAddedJustNow(true);
    setTimeout(() => setAddedJustNow(false), 1500);
  };

  const handleWishlistToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleWishlist(product.id);
  };

  return (
    <div
      onClick={handleCardClick}
      className="group relative bg-white border border-slate-200/90 rounded-xl overflow-hidden hover:border-slate-300 hover:shadow-md transition-all duration-200 cursor-pointer flex flex-col h-full"
    >
      {/* Product Image Area */}
      <div className="relative aspect-[4/3] bg-slate-50 overflow-hidden flex items-center justify-center p-3">
        {!imageError && product.images?.[0] ? (
          <img
            src={product.images[0]}
            alt={product.title}
            onError={() => setImageError(true)}
            referrerPolicy="no-referrer"
            className="w-full h-full object-contain mix-blend-multiply group-hover:scale-105 transition-transform duration-300"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center bg-slate-100 text-slate-400">
            <ShoppingBag className="w-8 h-8 stroke-1 mb-1" />
            <span className="text-[11px] font-medium">{product.brand}</span>
          </div>
        )}

        {/* Top Badges (Subtle, unboxed or minimal tag) */}
        <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
          {product.discountPercent > 0 && (
            <span className="bg-red-600 text-white text-[11px] font-bold px-2 py-0.5 rounded-sm">
              -{product.discountPercent}%
            </span>
          )}
          {product.isTradeAssurance && (
            <span className="bg-slate-900/80 backdrop-blur-xs text-white text-[10px] font-semibold px-2 py-0.5 rounded-sm flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-amber-400" />
              <span>Assurance</span>
            </span>
          )}
        </div>

        {/* Wishlist Button */}
        <button
          onClick={handleWishlistToggle}
          className={`absolute top-2.5 right-2.5 p-2 rounded-full transition-colors cursor-pointer ${
            isWish
              ? 'bg-red-50 text-red-600'
              : 'bg-white/90 text-slate-500 hover:text-slate-900 shadow-xs'
          }`}
          aria-label={isWish ? 'Remove from wishlist' : 'Add to wishlist'}
        >
          <Heart className={`w-4 h-4 ${isWish ? 'fill-current' : ''}`} />
        </button>
      </div>

      {/* Product Content Details */}
      <div className="p-4 flex flex-col flex-1 justify-between gap-3">
        <div>
          {/* Metadata: Category & Brand */}
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span className="font-semibold text-slate-700 uppercase tracking-wider text-[11px]">
              {product.brand}
            </span>
            <span aria-hidden="true">·</span>
            <span className="truncate">{product.category}</span>
          </div>

          {/* Product Title */}
          <h3 className="text-sm font-semibold text-slate-900 line-clamp-2 leading-snug group-hover:text-amber-700 transition-colors">
            {product.title}
          </h3>

          {/* Rating & Reviews */}
          <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-1.5">
            <div className="flex items-center text-amber-500">
              <Star className="w-3.5 h-3.5 fill-current" />
            </div>
            <span className="font-bold text-slate-800 tabular-nums">{product.rating.toFixed(1)}</span>
            <span className="text-slate-400">({product.reviewCount})</span>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <span className={product.stock > 0 ? 'text-emerald-700 font-medium' : 'text-red-600 font-medium'}>
              {product.stock > 0 ? `${product.stock} in stock` : 'Out of stock'}
            </span>
          </div>
        </div>

        {/* Price & Action Area */}
        <div className="pt-2 border-t border-slate-100 flex items-end justify-between gap-2">
          <div>
            <div className="text-base font-extrabold text-slate-900 tabular-nums">
              Rs. {product.price.toLocaleString()}
            </div>
            {product.originalPrice > product.price && (
              <div className="text-xs text-slate-400 line-through tabular-nums">
                Rs. {product.originalPrice.toLocaleString()}
              </div>
            )}
            {product.wholesalePrice && (
              <div className="text-[11px] text-slate-500 mt-0.5">
                Bulk: <span className="font-semibold text-slate-700">Rs. {product.wholesalePrice.toLocaleString()}</span> (3+)
              </div>
            )}
          </div>

          <button
            onClick={handleAddToCart}
            disabled={product.stock <= 0}
            className={`py-2 px-3 rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
              product.stock <= 0
                ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                : addedJustNow
                ? 'bg-emerald-600 text-white'
                : 'bg-slate-900 hover:bg-slate-800 text-white shadow-xs'
            }`}
          >
            {addedJustNow ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>Added</span>
              </>
            ) : (
              <>
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>Add</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
