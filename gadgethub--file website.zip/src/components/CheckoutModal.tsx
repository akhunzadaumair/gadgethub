import React, { useState } from 'react';
import {
  X,
  CheckCircle2,
  Truck,
  ShieldCheck,
  CreditCard,
  Building2,
  Smartphone,
  Printer,
  ShoppingBag,
  ArrowRight,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { CustomerDetails, PaymentMethod, Order } from '../types';
import { PAKISTAN_CITIES } from '../data/initialData';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenTracking: (orderId: string) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  onOpenTracking,
}) => {
  const {
    cart,
    cartSubtotal,
    cartShippingFee,
    cartDiscount,
    cartFinalTotal,
    placeOrder,
  } = useStore();

  const [formData, setFormData] = useState<CustomerDetails>({
    fullName: '',
    email: '',
    phone: '',
    address: '',
    city: 'Lahore',
    province: 'Punjab',
    postalCode: '54000',
    orderNotes: '',
  });

  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cod');
  const [createdOrder, setCreatedOrder] = useState<Order | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [checkoutError, setCheckoutError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.fullName.trim()) errs.fullName = 'Full name is required';
    if (!formData.email.trim() || !formData.email.includes('@')) {
      errs.email = 'Valid email address is required';
    }
    const cleanPhone = formData.phone.trim().replace(/[\s\-_()]/g, '');
    const normalized = cleanPhone.startsWith('+92')
      ? '0' + cleanPhone.slice(3)
      : cleanPhone.startsWith('92')
      ? '0' + cleanPhone.slice(2)
      : cleanPhone;

    if (!cleanPhone) {
      errs.phone = 'Phone number is required';
    } else if (!/^03\d{9}$/.test(normalized) && !/^\+?\d{10,14}$/.test(cleanPhone)) {
      errs.phone = 'Enter valid Pakistani mobile (e.g. 0329-3778337 or +923293778337)';
    }
    if (!formData.address.trim()) errs.address = 'Complete street delivery address is required';
    if (!formData.city) errs.city = 'Please select a city';

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    setCheckoutError(null);
    try {
      const cleanPhone = formData.phone.trim().replace(/[\s\-_()]/g, '');
      const normalized = cleanPhone.startsWith('+92')
        ? '0' + cleanPhone.slice(3)
        : cleanPhone.startsWith('92')
        ? '0' + cleanPhone.slice(2)
        : cleanPhone;

      const submissionData = {
        ...formData,
        phone: normalized,
      };
      const order = await placeOrder(submissionData, paymentMethod);
      setCreatedOrder(order);
    } catch (err: any) {
      console.error('Checkout error:', err);
      setCheckoutError(err?.message || 'Failed to place order. Please check item availability.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div
        className="relative bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50 shrink-0">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-600" />
            <h2 className="text-base font-bold text-slate-900">
              {createdOrder ? 'Order Confirmed' : 'Secure Nationwide Checkout'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="overflow-y-auto p-6 sm:p-8">
          {createdOrder ? (
            /* Order Success Receipt */
            <div className="space-y-6 max-w-2xl mx-auto text-center">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto mb-2">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <span className="text-xs uppercase tracking-wider font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-full">
                  Order Successfully Placed
                </span>
                <h1 className="text-2xl sm:text-3xl font-black text-slate-900 mt-2">
                  Thank You, {createdOrder.customer.fullName}!
                </h1>
                <p className="text-xs sm:text-sm text-slate-600 mt-1">
                  Your order confirmation invoice has been sent to{' '}
                  <strong className="text-slate-800">{createdOrder.customer.email}</strong>.
                </p>
              </div>

              {/* Order Key Metrics Box */}
              <div className="p-5 bg-slate-50 rounded-xl border border-slate-200 text-left space-y-3">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs border-b border-slate-200 pb-3">
                  <div>
                    <span className="text-slate-400 block text-[11px]">Order Number</span>
                    <span className="font-mono font-bold text-slate-900 text-sm">
                      {createdOrder.id}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[11px]">Courier Assigned</span>
                    <span className="font-semibold text-slate-800">
                      {createdOrder.courierName}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[11px]">Tracking Number</span>
                    <span className="font-mono font-bold text-amber-700">
                      {createdOrder.trackingNumber}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[11px]">Payment Type</span>
                    <span className="font-semibold text-slate-800 uppercase">
                      {createdOrder.paymentMethod}
                    </span>
                  </div>
                </div>

                {/* Items Summary */}
                <div className="space-y-2 pt-1">
                  <div className="text-xs font-bold text-slate-700 uppercase tracking-wide">
                    Ordered Gadgets
                  </div>
                  {createdOrder.items.map((item, idx) => (
                    <div key={idx} className="flex justify-between text-xs py-1 text-slate-600">
                      <span>
                        {item.quantity}x {item.product.title}
                      </span>
                      <span className="font-mono text-slate-900 font-medium tabular-nums">
                        Rs. {(item.product.price * item.quantity).toLocaleString()}
                      </span>
                    </div>
                  ))}
                  <div className="border-t border-slate-200 pt-2 flex justify-between text-sm font-bold text-slate-900">
                    <span>Total Payable (COD):</span>
                    <span className="font-mono text-base text-slate-900 tabular-nums">
                      Rs. {createdOrder.total.toLocaleString()}
                    </span>
                  </div>
                </div>

                <div className="pt-2 text-xs text-slate-500 bg-amber-50/60 p-3 rounded-lg border border-amber-200/60">
                  <span className="font-bold text-amber-900 block">Shipping to:</span>
                  <span>
                    {createdOrder.customer.address}, {createdOrder.customer.city} (Tel: {createdOrder.customer.phone})
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                <button
                  onClick={() => {
                    onClose();
                    onOpenTracking(createdOrder.id);
                  }}
                  className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs py-3 px-5 rounded-lg transition-colors cursor-pointer flex items-center gap-2"
                >
                  <Truck className="w-4 h-4" />
                  <span>Track Courier Shipment</span>
                </button>
                <button
                  onClick={handlePrint}
                  className="border border-slate-300 hover:bg-slate-50 text-slate-700 font-semibold text-xs py-3 px-4 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print Receipt</span>
                </button>
                <button
                  onClick={onClose}
                  className="text-xs text-slate-600 hover:text-slate-900 font-medium px-4 py-3"
                >
                  Back to Store
                </button>
              </div>
            </div>
          ) : (
            /* Checkout Form */
            <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              {/* Left Column: Customer & Delivery Info */}
              <div className="lg:col-span-7 space-y-6">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide mb-3 flex items-center gap-2">
                    <Truck className="w-4 h-4 text-amber-600" />
                    <span>1. Shipping & Customer Details</span>
                  </h3>

                  <div className="space-y-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        value={formData.fullName}
                        onChange={(e) =>
                          setFormData({ ...formData, fullName: e.target.value })
                        }
                        placeholder="e.g. Muhammad Usman"
                        className={`w-full py-2.5 px-3 text-xs bg-white border rounded-lg focus:outline-none focus:border-slate-900 ${
                          errors.fullName ? 'border-red-500' : 'border-slate-300'
                        }`}
                      />
                      {errors.fullName && (
                        <p className="text-[11px] text-red-500 mt-1">{errors.fullName}</p>
                      )}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Email Address *
                        </label>
                        <input
                          type="email"
                          value={formData.email}
                          onChange={(e) =>
                            setFormData({ ...formData, email: e.target.value })
                          }
                          placeholder="name@example.com"
                          className={`w-full py-2.5 px-3 text-xs bg-white border rounded-lg focus:outline-none focus:border-slate-900 ${
                            errors.email ? 'border-red-500' : 'border-slate-300'
                          }`}
                        />
                        {errors.email && (
                          <p className="text-[11px] text-red-500 mt-1">{errors.email}</p>
                        )}
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Phone Number (for Courier SMS) *
                        </label>
                        <input
                          type="text"
                          value={formData.phone}
                          onChange={(e) =>
                            setFormData({ ...formData, phone: e.target.value })
                          }
                          placeholder="0300-1234567"
                          className={`w-full py-2.5 px-3 text-xs bg-white border rounded-lg focus:outline-none focus:border-slate-900 ${
                            errors.phone ? 'border-red-500' : 'border-slate-300'
                          }`}
                        />
                        {errors.phone && (
                          <p className="text-[11px] text-red-500 mt-1">{errors.phone}</p>
                        )}
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Street Address & House / Flat # *
                      </label>
                      <input
                        type="text"
                        value={formData.address}
                        onChange={(e) =>
                          setFormData({ ...formData, address: e.target.value })
                        }
                        placeholder="House # 12, Street 5, Phase 4..."
                        className={`w-full py-2.5 px-3 text-xs bg-white border rounded-lg focus:outline-none focus:border-slate-900 ${
                          errors.address ? 'border-red-500' : 'border-slate-300'
                        }`}
                      />
                      {errors.address && (
                        <p className="text-[11px] text-red-500 mt-1">{errors.address}</p>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          City (Pakistan) *
                        </label>
                        <select
                          value={formData.city}
                          onChange={(e) =>
                            setFormData({ ...formData, city: e.target.value })
                          }
                          className="w-full py-2.5 px-3 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900 cursor-pointer"
                        >
                          {PAKISTAN_CITIES.map((c) => (
                            <option key={c} value={c}>
                              {c}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Postal / Zip Code
                        </label>
                        <input
                          type="text"
                          value={formData.postalCode}
                          onChange={(e) =>
                            setFormData({ ...formData, postalCode: e.target.value })
                          }
                          placeholder="54000"
                          className="w-full py-2.5 px-3 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Delivery Instructions (Optional)
                      </label>
                      <textarea
                        value={formData.orderNotes}
                        onChange={(e) =>
                          setFormData({ ...formData, orderNotes: e.target.value })
                        }
                        rows={2}
                        placeholder="Call before arrival, leave with security guard, etc."
                        className="w-full py-2 px-3 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900"
                      />
                    </div>
                  </div>
                </div>

                {/* Payment Method Selector */}
                <div>
                  <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide mb-3 flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-emerald-600" />
                    <span>2. Select Payment Method</span>
                  </h3>

                  <div className="space-y-2.5">
                    {/* Cash on Delivery (COD) Option */}
                    <label
                      className={`flex items-start gap-3 p-3.5 rounded-xl border cursor-pointer transition-colors ${
                        paymentMethod === 'cod'
                          ? 'border-slate-900 bg-amber-50/40 ring-1 ring-slate-900'
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <input
                        type="radio"
                        name="payment"
                        checked={paymentMethod === 'cod'}
                        onChange={() => setPaymentMethod('cod')}
                        className="mt-1 text-slate-900 focus:ring-0"
                      />
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-slate-900">
                            Cash on Delivery (COD) - Recommended
                          </span>
                          <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-sm">
                            0% Extra Fee
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">
                          Pay in cash directly to the TCS / Leopards courier rider when you inspect the parcel.
                        </p>
                      </div>
                    </label>

                    {/* JazzCash / Easypaisa */}
                    <label
                      className={`flex items-start gap-3 p-3.5 rounded-xl border cursor-pointer transition-colors ${
                        paymentMethod === 'jazzcash'
                          ? 'border-slate-900 bg-amber-50/40 ring-1 ring-slate-900'
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <input
                        type="radio"
                        name="payment"
                        checked={paymentMethod === 'jazzcash'}
                        onChange={() => setPaymentMethod('jazzcash')}
                        className="mt-1 text-slate-900 focus:ring-0"
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <Smartphone className="w-4 h-4 text-red-600" />
                          <span className="text-xs font-bold text-slate-900">
                            JazzCash / Easypaisa Direct
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">
                          Send payment to Till ID #094819 or Account 0300-4234387.
                        </p>
                      </div>
                    </label>

                    {/* Bank Wire */}
                    <label
                      className={`flex items-start gap-3 p-3.5 rounded-xl border cursor-pointer transition-colors ${
                        paymentMethod === 'bank_transfer'
                          ? 'border-slate-900 bg-amber-50/40 ring-1 ring-slate-900'
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <input
                        type="radio"
                        name="payment"
                        checked={paymentMethod === 'bank_transfer'}
                        onChange={() => setPaymentMethod('bank_transfer')}
                        className="mt-1 text-slate-900 focus:ring-0"
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <Building2 className="w-4 h-4 text-blue-600" />
                          <span className="text-xs font-bold text-slate-900">
                            Direct Bank Transfer (Meezan / HBL)
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">
                          Account details provided upon order placement for IBFT transfer.
                        </p>
                      </div>
                    </label>
                  </div>
                </div>
              </div>

              {/* Right Column: Order Summary */}
              <div className="lg:col-span-5 bg-slate-50 p-5 sm:p-6 rounded-2xl border border-slate-200 flex flex-col justify-between space-y-6">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide pb-3 border-b border-slate-200 flex items-center justify-between">
                    <span>Order Summary</span>
                    <span className="text-xs text-slate-500 font-normal">
                      {cart.length} items
                    </span>
                  </h3>

                  {/* Cart preview */}
                  <div className="max-h-56 overflow-y-auto divide-y divide-slate-200/80 py-2">
                    {cart.map((item) => (
                      <div key={item.product.id} className="py-2.5 flex gap-3 text-xs">
                        <img
                          src={item.product.images[0]}
                          alt=""
                          referrerPolicy="no-referrer"
                          className="w-12 h-12 rounded object-contain bg-white border border-slate-200 p-1 shrink-0"
                        />
                        <div className="flex-1 min-w-0">
                          <h5 className="font-semibold text-slate-900 truncate">
                            {item.product.title}
                          </h5>
                          <div className="text-slate-500 text-[11px]">
                            Qty: {item.quantity} · Rs. {item.product.price.toLocaleString()}
                          </div>
                        </div>
                        <div className="font-mono font-bold text-slate-900 tabular-nums">
                          Rs. {(item.product.price * item.quantity).toLocaleString()}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Totals */}
                  <div className="border-t border-slate-200 pt-3 space-y-2 text-xs text-slate-600">
                    <div className="flex justify-between">
                      <span>Subtotal</span>
                      <span className="font-mono text-slate-900 tabular-nums">
                        Rs. {cartSubtotal.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Nationwide Courier Delivery</span>
                      <span className="font-mono text-slate-900 tabular-nums">
                        {cartShippingFee === 0 ? (
                          <span className="text-emerald-700 font-bold">FREE</span>
                        ) : (
                          `Rs. ${cartShippingFee.toLocaleString()}`
                        )}
                      </span>
                    </div>
                    {cartDiscount > 0 && (
                      <div className="flex justify-between text-emerald-700 font-semibold">
                        <span>Discount Voucher</span>
                        <span className="font-mono tabular-nums">-Rs. {cartDiscount.toLocaleString()}</span>
                      </div>
                    )}
                    <div className="border-t border-slate-200 pt-2 flex justify-between text-base font-black text-slate-900">
                      <span>Total Amount:</span>
                      <span className="font-mono text-lg text-slate-950 tabular-nums">
                        Rs. {cartFinalTotal.toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  {checkoutError && (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs font-medium text-left flex items-start gap-2">
                      <span className="text-red-500 font-bold shrink-0">⚠️</span>
                      <span>{checkoutError}</span>
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={isSubmitting || cart.length === 0}
                    className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs sm:text-sm py-3.5 px-4 rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-xs disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <span>Placing Order...</span>
                    ) : (
                      <>
                        <span>Confirm & Place Order (COD)</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>

                  <div className="text-[11px] text-slate-500 text-center space-y-1">
                    <div className="flex items-center justify-center gap-1.5 text-emerald-700 font-semibold">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>7-Day Replacement Guarantee & Sealed Delivery</span>
                    </div>
                    <p>No credit card required. Pay cash to courier rider upon delivery.</p>
                  </div>
                </div>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
