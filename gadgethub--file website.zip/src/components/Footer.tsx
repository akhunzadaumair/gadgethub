import React, { useState } from 'react';
import { ShieldCheck, Truck, Headphones, Mail, Phone, MapPin, Check } from 'lucide-react';
import { useStore } from '../context/StoreContext';

interface FooterProps {
  onOpenTracking: () => void;
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenTracking, onOpenAdmin }) => {
  const { categories, setFilters } = useStore();
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.trim()) return;
    setSubscribed(true);
    setNewsletterEmail('');
    setTimeout(() => setSubscribed(false), 3000);
  };

  const handleCategoryClick = (catId: string) => {
    setFilters((prev) => ({ ...prev, categoryId: catId }));
    const el = document.getElementById('products-section');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="bg-slate-900 text-slate-400 border-t border-slate-800 text-xs">
      {/* Upper Newsletter & Guarantee Strip */}
      <div className="border-b border-slate-800 py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          <div className="md:col-span-6 space-y-2">
            <h3 className="text-lg font-bold text-white tracking-tight">
              Get Pakistani Tech Deals & Restock Alerts
            </h3>
            <p className="text-xs text-slate-400 max-w-md leading-relaxed">
              Subscribe to Gadgethub's weekly newsletter for flash discounts, wholesale tier promos, and new PTA-approved arrivals.
            </p>
          </div>

          <div className="md:col-span-6">
            <form onSubmit={handleSubscribe} className="flex gap-2 max-w-md ml-auto">
              <input
                type="email"
                required
                value={newsletterEmail}
                onChange={(e) => setNewsletterEmail(e.target.value)}
                placeholder="Enter your email address"
                className="flex-1 py-2.5 px-3.5 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-500 text-xs"
              />
              <button
                type="submit"
                className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-4 py-2.5 rounded-lg transition-colors cursor-pointer shrink-0 text-xs flex items-center gap-1.5"
              >
                {subscribed ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>Joined!</span>
                  </>
                ) : (
                  <span>Subscribe</span>
                )}
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8">
        {/* Col 1: Brand Info */}
        <div className="space-y-3">
          <div className="text-xl font-black text-white tracking-tight">
            Gadget<span className="text-amber-500">hub</span>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            Pakistan's premier direct-to-consumer tech marketplace. Sourcing authentic electronics, mobile devices, audio gear, and appliances with Trade Assurance.
          </p>
          <div className="space-y-1.5 pt-2 text-slate-300">
            <div className="flex items-center gap-2">
              <Phone className="w-3.5 h-3.5 text-amber-500" />
              <span>Helpline: 0300-4234387 (Mon-Sat, 9AM-9PM)</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="w-3.5 h-3.5 text-amber-500" />
              <span>orders@gadgethub.pk</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-3.5 h-3.5 text-amber-500" />
              <span>Main Boulevard, Gulberg III, Lahore, Pakistan</span>
            </div>
          </div>
        </div>

        {/* Col 2: Top Categories */}
        <div className="space-y-3">
          <h4 className="text-white font-bold text-xs uppercase tracking-wider">
            Popular Categories
          </h4>
          <ul className="space-y-2">
            {categories.slice(0, 6).map((c) => (
              <li key={c.id}>
                <button
                  onClick={() => handleCategoryClick(c.id)}
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  {c.name}
                </button>
              </li>
            ))}
          </ul>
        </div>

        {/* Col 3: Customer Service */}
        <div className="space-y-3">
          <h4 className="text-white font-bold text-xs uppercase tracking-wider">
            Customer Assurance
          </h4>
          <ul className="space-y-2">
            <li>
              <button
                onClick={onOpenTracking}
                className="hover:text-white transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Truck className="w-3.5 h-3.5 text-amber-500" />
                <span>Track TCS / Leopards Courier</span>
              </button>
            </li>
            <li>Cash on Delivery (COD) Inspection</li>
            <li>7 Days Replacement Policy</li>
            <li>Official Brand PTA Approval</li>
            <li>Wholesale & B2B Volume Pricing</li>
            <li>
              <button
                onClick={onOpenAdmin}
                className="hover:text-white transition-colors cursor-pointer text-slate-500 hover:text-slate-300"
              >
                Store Owner Portal
              </button>
            </li>
          </ul>
        </div>

        {/* Col 4: Nationwide Payment Methods */}
        <div className="space-y-3">
          <h4 className="text-white font-bold text-xs uppercase tracking-wider">
            Accepted Payments in Pakistan
          </h4>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-2 rounded bg-slate-800/80 border border-slate-700/60 font-semibold text-slate-200">
              💵 Cash on Delivery
            </div>
            <div className="p-2 rounded bg-slate-800/80 border border-slate-700/60 font-semibold text-slate-200">
              📱 JazzCash / EP
            </div>
            <div className="p-2 rounded bg-slate-800/80 border border-slate-700/60 font-semibold text-slate-200">
              🏦 Bank IBFT (HBL/Meezan)
            </div>
            <div className="p-2 rounded bg-slate-800/80 border border-slate-700/60 font-semibold text-slate-200">
              💳 Visa & Mastercard
            </div>
          </div>
          <div className="text-[11px] text-slate-500 pt-2 leading-relaxed">
            All orders dispatch with sealed tamper-evident security tape. Inspect packaging before paying courier.
          </div>
        </div>
      </div>

      {/* Bottom Copyright */}
      <div className="border-t border-slate-800 py-6 text-slate-500 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>
            © {new Date().getFullYear()} Gadgethub Pakistan (Private) Limited. All rights reserved.
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <span>Privacy Policy</span>
            <span>·</span>
            <span>Terms of Service</span>
            <span>·</span>
            <span>PTA Compliance</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
