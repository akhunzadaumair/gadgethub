import React from 'react';
import { ShieldCheck, Truck, RotateCcw, Headphones, ArrowRight, Sparkles } from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const HeroBanner: React.FC = () => {
  const { setFilters, products, setSelectedProduct } = useStore();

  const handleExploreClick = () => {
    const el = document.getElementById('products-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleFeaturedPhone = () => {
    const phone = products.find((p) => p.id === 'gh-phone-pro-max');
    if (phone) {
      setSelectedProduct(phone);
    }
  };

  return (
    <section className="bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Column: Bold Campaign Prose */}
          <div className="lg:col-span-6 space-y-6">
            <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-wide text-amber-700 bg-amber-50 border border-amber-200/80 px-3 py-1.5 rounded-md">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Official Pakistan Tech Superstore · 2026 Edition</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight leading-[1.15]" style={{ textWrap: 'balance' }}>
              Next-generation gadgets & consumer electronics in Pakistan.
            </h1>

            <p className="text-slate-600 text-sm sm:text-base leading-relaxed max-w-xl">
              From PTA-approved flagship smartphones and studio-grade ANC headphones to high-speed GaN chargers and smart robotics. Order with 100% Cash on Delivery across all 150+ Pakistani cities.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={handleExploreClick}
                className="bg-slate-900 hover:bg-slate-800 text-white font-medium text-xs sm:text-sm py-3 px-6 rounded-lg transition-colors cursor-pointer flex items-center gap-2 shadow-xs"
              >
                <span>Browse Full Catalog</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={handleFeaturedPhone}
                className="bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 font-medium text-xs sm:text-sm py-3 px-5 rounded-lg transition-colors cursor-pointer"
              >
                <span>View TitanEdge Pro Max</span>
              </button>
            </div>

            {/* Quick Micro-Trust Badges */}
            <div className="pt-4 border-t border-slate-200/80 grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs text-slate-600">
              <div>
                <span className="font-bold text-slate-900 block text-sm tabular-nums">150+</span>
                <span>Cities delivery</span>
              </div>
              <div>
                <span className="font-bold text-slate-900 block text-sm tabular-nums">100%</span>
                <span>Authentic & sealed</span>
              </div>
              <div className="col-span-2 sm:col-span-1">
                <span className="font-bold text-slate-900 block text-sm tabular-nums">7 Days</span>
                <span>Easy replacement</span>
              </div>
            </div>
          </div>

          {/* Right Column: Hero Visual Showcase */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-2xl overflow-hidden border border-slate-200/90 bg-white shadow-sm">
              <img
                src="/src/assets/images/hero_gadgethub_flagship_1792425083981.jpg"
                alt="Gadgethub flagship electronics showcase"
                referrerPolicy="no-referrer"
                className="w-full h-[320px] sm:h-[420px] object-cover"
                loading="eager"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end p-6">
                <div className="text-white space-y-1">
                  <div className="text-xs uppercase tracking-wider font-bold text-amber-400">
                    Featured Ecosystem
                  </div>
                  <h3 className="text-lg sm:text-xl font-bold">
                    Flagship 5G, ANC Acoustics & M-Silicon Workstations
                  </h3>
                  <p className="text-xs text-slate-200 max-w-md">
                    Direct brand warranty backed by Gadgethub Trade Assurance.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 4-Column Trust Strip Below Hero Split */}
        <div className="mt-10 pt-8 border-t border-slate-200 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="flex items-start gap-3.5 p-3 rounded-lg bg-white border border-slate-200/70">
            <div className="p-2.5 rounded-md bg-amber-50 text-amber-700 shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900">Cash on Delivery (COD)</h4>
              <p className="text-xs text-slate-500 mt-0.5">Pay at your doorstep with TCS & Leopards Courier.</p>
            </div>
          </div>

          <div className="flex items-start gap-3.5 p-3 rounded-lg bg-white border border-slate-200/70">
            <div className="p-2.5 rounded-md bg-emerald-50 text-emerald-700 shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900">Trade Assurance & PTA</h4>
              <p className="text-xs text-slate-500 mt-0.5">100% Tax-paid official devices with sealed warranty.</p>
            </div>
          </div>

          <div className="flex items-start gap-3.5 p-3 rounded-lg bg-white border border-slate-200/70">
            <div className="p-2.5 rounded-md bg-blue-50 text-blue-700 shrink-0">
              <RotateCcw className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900">7-Day Replacement</h4>
              <p className="text-xs text-slate-500 mt-0.5">Hassle-free replacement for any transit defects.</p>
            </div>
          </div>

          <div className="flex items-start gap-3.5 p-3 rounded-lg bg-white border border-slate-200/70">
            <div className="p-2.5 rounded-md bg-purple-50 text-purple-700 shrink-0">
              <Headphones className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900">Pakistani Customer Helpline</h4>
              <p className="text-xs text-slate-500 mt-0.5">Instant WhatsApp & phone support 7 days a week.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
