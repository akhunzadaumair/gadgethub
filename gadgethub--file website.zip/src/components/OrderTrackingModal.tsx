import React, { useState } from 'react';
import { X, Search, Truck, CheckCircle2, Clock, PackageCheck, AlertCircle, MapPin } from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { Order, OrderStatus } from '../types';

interface OrderTrackingModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialOrderId?: string;
}

export const OrderTrackingModal: React.FC<OrderTrackingModalProps> = ({
  isOpen,
  onClose,
  initialOrderId = '',
}) => {
  const { orders, lookupOrder } = useStore();
  const [searchTerm, setSearchTerm] = useState(initialOrderId || (orders[0]?.id || ''));
  const [foundOrder, setFoundOrder] = useState<Order | undefined>(() =>
    lookupOrder(initialOrderId || (orders[0]?.id || ''))
  );
  const [hasSearched, setHasSearched] = useState(false);

  if (!isOpen) return null;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const result = lookupOrder(searchTerm);
    setFoundOrder(result);
    setHasSearched(true);
  };

  const handleSelectSample = (orderId: string) => {
    setSearchTerm(orderId);
    setFoundOrder(lookupOrder(orderId));
    setHasSearched(true);
  };

  const getStepProgress = (status: OrderStatus) => {
    switch (status) {
      case 'Pending':
        return 1;
      case 'Confirmed':
      case 'Processing':
        return 2;
      case 'Shipped':
        return 3;
      case 'Delivered':
        return 4;
      default:
        return 1;
    }
  };

  const currentStep = foundOrder ? getStepProgress(foundOrder.status) : 1;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div
        className="relative bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50 shrink-0">
          <div className="flex items-center gap-2">
            <Truck className="w-5 h-5 text-amber-600" />
            <h2 className="text-base font-bold text-slate-900">
              Track Pakistan Courier Shipment
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="overflow-y-auto p-6 space-y-6">
          {/* Search Form */}
          <form onSubmit={handleSearch} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Enter Order ID (e.g. GH-PK-89211) or Tracking #"
                className="w-full pl-10 pr-3 py-2.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900 font-mono"
              />
            </div>
            <button
              type="submit"
              className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold px-4 py-2.5 rounded-lg transition-colors cursor-pointer shrink-0"
            >
              Track Order
            </button>
          </form>

          {/* Sample quick selector */}
          {orders.length > 0 && (
            <div className="text-xs text-slate-500 flex flex-wrap items-center gap-2">
              <span className="font-semibold text-slate-700">Recent orders:</span>
              {orders.slice(0, 3).map((ord) => (
                <button
                  key={ord.id}
                  type="button"
                  onClick={() => handleSelectSample(ord.id)}
                  className={`px-2 py-1 rounded text-[11px] font-mono border transition-colors cursor-pointer ${
                    foundOrder?.id === ord.id
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border-slate-200'
                  }`}
                >
                  {ord.id} ({ord.status})
                </button>
              ))}
            </div>
          )}

          {foundOrder ? (
            /* Order Details & Timeline */
            <div className="space-y-6">
              {/* Order Banner */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
                <div>
                  <div className="font-bold text-slate-900 text-sm font-mono">
                    {foundOrder.id}
                  </div>
                  <div className="text-slate-500 mt-0.5">
                    Placed on {new Date(foundOrder.date).toLocaleDateString('en-PK', { dateStyle: 'medium' })}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Status:</span>
                  <span
                    className={`font-bold px-2.5 py-1 rounded-sm uppercase tracking-wider text-[10px] ${
                      foundOrder.status === 'Delivered'
                        ? 'bg-emerald-100 text-emerald-800'
                        : foundOrder.status === 'Shipped'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {foundOrder.status}
                  </span>
                </div>
              </div>

              {/* Progress Timeline */}
              <div className="py-2">
                <div className="grid grid-cols-4 relative text-center text-xs">
                  {/* Progress Line */}
                  <div className="absolute top-4 left-[12%] right-[12%] h-0.5 bg-slate-200 -z-0">
                    <div
                      className="h-full bg-slate-900 transition-all duration-500"
                      style={{
                        width: `${Math.min(100, Math.max(0, ((currentStep - 1) / 3) * 100))}%`,
                      }}
                    />
                  </div>

                  {/* Step 1 */}
                  <div className="flex flex-col items-center relative z-10">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                        currentStep >= 1
                          ? 'bg-slate-900 text-white'
                          : 'bg-white border-2 border-slate-300 text-slate-400'
                      }`}
                    >
                      <Clock className="w-4 h-4" />
                    </div>
                    <span className="font-semibold text-slate-800 mt-2">Placed</span>
                    <span className="text-[10px] text-slate-400">Order Received</span>
                  </div>

                  {/* Step 2 */}
                  <div className="flex flex-col items-center relative z-10">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                        currentStep >= 2
                          ? 'bg-slate-900 text-white'
                          : 'bg-white border-2 border-slate-300 text-slate-400'
                      }`}
                    >
                      <PackageCheck className="w-4 h-4" />
                    </div>
                    <span className="font-semibold text-slate-800 mt-2">Processing</span>
                    <span className="text-[10px] text-slate-400">QC & Packed</span>
                  </div>

                  {/* Step 3 */}
                  <div className="flex flex-col items-center relative z-10">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                        currentStep >= 3
                          ? 'bg-slate-900 text-white'
                          : 'bg-white border-2 border-slate-300 text-slate-400'
                      }`}
                    >
                      <Truck className="w-4 h-4" />
                    </div>
                    <span className="font-semibold text-slate-800 mt-2">Shipped</span>
                    <span className="text-[10px] text-slate-400">With Courier</span>
                  </div>

                  {/* Step 4 */}
                  <div className="flex flex-col items-center relative z-10">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                        currentStep >= 4
                          ? 'bg-emerald-600 text-white'
                          : 'bg-white border-2 border-slate-300 text-slate-400'
                      }`}
                    >
                      <CheckCircle2 className="w-4 h-4" />
                    </div>
                    <span className="font-semibold text-slate-800 mt-2">Delivered</span>
                    <span className="text-[10px] text-slate-400">Payment Settled</span>
                  </div>
                </div>
              </div>

              {/* Courier info box */}
              <div className="p-4 rounded-xl border border-slate-200 bg-white grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="space-y-1">
                  <span className="text-slate-400 block text-[11px]">Courier Partner</span>
                  <span className="font-bold text-slate-900 text-sm">{foundOrder.courierName}</span>
                  <div className="text-slate-600 font-mono text-[11px]">
                    Consignment: <strong>{foundOrder.trackingNumber}</strong>
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-slate-400 block text-[11px]">Destination</span>
                  <div className="flex items-center gap-1 font-semibold text-slate-800">
                    <MapPin className="w-3.5 h-3.5 text-amber-600" />
                    <span>
                      {foundOrder.customer.city}, {foundOrder.customer.province}
                    </span>
                  </div>
                  <div className="text-slate-500 text-[11px] truncate">
                    {foundOrder.customer.address}
                  </div>
                </div>
              </div>

              {/* Items in shipment */}
              <div>
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide mb-2">
                  Items in this shipment
                </h4>
                <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg p-2 bg-slate-50">
                  {foundOrder.items.map((item, idx) => (
                    <div key={idx} className="py-2 px-2 flex justify-between items-center text-xs">
                      <div className="flex items-center gap-2">
                        <img
                          src={item.product.images[0]}
                          alt=""
                          referrerPolicy="no-referrer"
                          className="w-8 h-8 rounded object-contain bg-white border border-slate-200"
                        />
                        <span className="font-medium text-slate-800">
                          {item.quantity}x {item.product.title}
                        </span>
                      </div>
                      <span className="font-mono text-slate-900 font-semibold tabular-nums">
                        Rs. {(item.product.price * item.quantity).toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            hasSearched && (
              <div className="text-center py-8 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                <AlertCircle className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                <h3 className="text-sm font-bold text-slate-800">Order not found</h3>
                <p className="text-xs text-slate-500 mt-1">
                  Please verify the Order ID or consignment number.
                </p>
              </div>
            )
          )}
        </div>
      </div>
    </div>
  );
};
