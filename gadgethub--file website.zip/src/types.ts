export interface Product {
  id: string;
  title: string;
  slug: string;
  category: string;
  categoryId: string;
  brand: string;
  price: number; // in PKR
  originalPrice: number; // in PKR
  discountPercent: number;
  stock: number;
  rating: number;
  reviewCount: number;
  images: string[];
  description: string;
  specs: Record<string, string>;
  isFeatured?: boolean;
  isBestSeller?: boolean;
  isNewArrival?: boolean;
  isTradeAssurance?: boolean;
  moq?: number; // Minimum order quantity (Alibaba style)
  wholesalePrice?: number; // Price when ordering 3+ units
  sku: string;
  warranty: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  iconName: string;
  description: string;
  itemCount: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedColor?: string;
  selectedVariant?: string;
}

export interface CustomerDetails {
  fullName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  province: string;
  postalCode: string;
  orderNotes?: string;
}

export type PaymentMethod = 'cod' | 'jazzcash' | 'easypaisa' | 'bank_transfer' | 'card';

export type OrderStatus = 'Pending' | 'Confirmed' | 'Processing' | 'Shipped' | 'Delivered' | 'Cancelled';

export interface NotificationDelivery {
  status: 'pending' | 'sent' | 'failed' | 'not_configured';
  recipient: string;
  sentAt?: string;
  error?: string;
  messageId?: string;
  provider?: string;
}

export interface OrderNotifications {
  email: NotificationDelivery;
  whatsapp: NotificationDelivery;
}

export interface Order {
  id: string;
  date: string;
  customer: CustomerDetails;
  items: CartItem[];
  subtotal: number;
  shippingFee: number;
  discount: number;
  total: number;
  paymentMethod: PaymentMethod;
  status: OrderStatus;
  trackingNumber: string;
  courierName: string;
  notifications?: OrderNotifications;
}

export interface FilterOptions {
  searchQuery: string;
  categoryId: string;
  minPrice: number;
  maxPrice: number;
  sortBy: 'featured' | 'price-asc' | 'price-desc' | 'rating' | 'newest';
  inStockOnly: boolean;
}
