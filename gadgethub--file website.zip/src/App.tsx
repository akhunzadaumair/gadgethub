/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { StoreProvider, useStore } from './context/StoreContext';
import { Header } from './components/Header';
import { HeroBanner } from './components/HeroBanner';
import { CategoryShowcase } from './components/CategoryShowcase';
import { ProductGrid } from './components/ProductGrid';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { OrderTrackingModal } from './components/OrderTrackingModal';
import { WishlistModal } from './components/WishlistModal';
import { AdminModal } from './components/AdminModal';
import { Footer } from './components/Footer';

function StoreMain() {
  const { setSelectedProduct } = useStore();

  const [cartOpen, setCartOpen] = useState(false);
  const [wishlistOpen, setWishlistOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [trackingOpen, setTrackingOpen] = useState(false);
  const [trackingOrderId, setTrackingOrderId] = useState<string | undefined>(undefined);
  const [adminOpen, setAdminOpen] = useState(false);

  const handleOpenTrackingWithId = (orderId: string) => {
    setTrackingOrderId(orderId);
    setTrackingOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-white text-slate-900">
      {/* Sticky Header */}
      <Header
        onOpenCart={() => setCartOpen(true)}
        onOpenWishlist={() => setWishlistOpen(true)}
        onOpenTracking={() => {
          setTrackingOrderId(undefined);
          setTrackingOpen(true);
        }}
        onOpenAdmin={() => setAdminOpen(true)}
      />

      {/* Main Storefront Flow */}
      <main className="flex-1">
        {/* Campaign Hero Showcase */}
        <HeroBanner />

        {/* Categories Horizontal Discovery */}
        <CategoryShowcase />

        {/* Interactive Marketplace Catalog */}
        <ProductGrid />
      </main>

      {/* Store Footer */}
      <Footer
        onOpenTracking={() => {
          setTrackingOrderId(undefined);
          setTrackingOpen(true);
        }}
        onOpenAdmin={() => setAdminOpen(true)}
      />

      {/* Product Detail Modal */}
      <ProductDetailModal onOpenCheckout={() => setCheckoutOpen(true)} />

      {/* Slide-over Cart Drawer */}
      <CartDrawer
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        onProceedCheckout={() => setCheckoutOpen(true)}
      />

      {/* Full Checkout Modal */}
      <CheckoutModal
        isOpen={checkoutOpen}
        onClose={() => setCheckoutOpen(false)}
        onOpenTracking={handleOpenTrackingWithId}
      />

      {/* Order Tracking Modal */}
      <OrderTrackingModal
        isOpen={trackingOpen}
        onClose={() => setTrackingOpen(false)}
        initialOrderId={trackingOrderId}
      />

      {/* Wishlist Modal */}
      <WishlistModal
        isOpen={wishlistOpen}
        onClose={() => setWishlistOpen(false)}
        onOpenProduct={(product) => setSelectedProduct(product)}
      />

      {/* Merchant / Admin Modal */}
      <AdminModal
        isOpen={adminOpen}
        onClose={() => setAdminOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <StoreMain />
    </StoreProvider>
  );
}
