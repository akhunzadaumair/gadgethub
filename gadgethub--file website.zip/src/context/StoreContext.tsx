import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Product, Category, CartItem, Order, CustomerDetails, PaymentMethod, OrderStatus, FilterOptions } from '../types';
import { INITIAL_PRODUCTS, INITIAL_CATEGORIES, INITIAL_ORDERS } from '../data/initialData';

interface Coupon {
  code: string;
  discountType: 'percentage' | 'flat';
  value: number;
  minOrder: number;
}

const AVAILABLE_COUPONS: Record<string, Coupon> = {
  'GADGET10': { code: 'GADGET10', discountType: 'percentage', value: 10, minOrder: 5000 },
  'WELCOME500': { code: 'WELCOME500', discountType: 'flat', value: 500, minOrder: 3000 },
  'SUPERDEAL': { code: 'SUPERDEAL', discountType: 'percentage', value: 15, minOrder: 15000 },
};

interface StoreContextType {
  products: Product[];
  categories: Category[];
  cart: CartItem[];
  wishlist: string[]; // product IDs
  orders: Order[];
  isAdmin: boolean;
  adminPasswordError: string | null;
  selectedProduct: Product | null;
  filters: FilterOptions;
  cartTotalCount: number;
  cartSubtotal: number;
  cartShippingFee: number;
  cartDiscount: number;
  cartFinalTotal: number;
  appliedCoupon: Coupon | null;
  couponError: string | null;
  isLoadingData: boolean;

  // Cart actions
  addToCart: (product: Product, quantity?: number, selectedColor?: string) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  applyCoupon: (code: string) => boolean;
  removeCoupon: () => void;

  // Wishlist actions
  toggleWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;

  // Order actions
  placeOrder: (customer: CustomerDetails, paymentMethod: PaymentMethod) => Promise<Order>;
  updateOrderStatus: (orderId: string, status: OrderStatus) => Promise<void>;
  deleteOrder: (orderId: string) => Promise<boolean>;
  lookupOrder: (orderId: string) => Order | undefined;
  retryNotification: (orderId: string, channel?: 'all' | 'email' | 'whatsapp') => Promise<{ success: boolean; error?: string }>;

  // Admin actions
  loginAdmin: (password: string) => Promise<boolean>;
  logoutAdmin: () => void;
  addProduct: (product: Omit<Product, 'id'>) => Promise<Product>;
  updateProduct: (id: string, updates: Partial<Product>) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  uploadImage: (file: File) => Promise<string>;
  resetAllData: () => Promise<void>;
  syncCatalogWithSupabase: () => Promise<void>;

  // Navigation & Detail Modal
  setSelectedProduct: (product: Product | null) => void;
  setFilters: React.Dispatch<React.SetStateAction<FilterOptions>>;
  resetFilters: () => void;
  refreshProducts: () => Promise<void>;
  refreshOrders: () => Promise<void>;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

const STORAGE_KEYS = {
  PRODUCTS: 'gadgethub_products_v1',
  CART: 'gadgethub_cart_v1',
  WISHLIST: 'gadgethub_wishlist_v1',
  ORDERS: 'gadgethub_orders_v1',
  ADMIN_TOKEN: 'gadgethub_admin_token_v1',
};

const DEFAULT_FILTERS: FilterOptions = {
  searchQuery: '',
  categoryId: 'all',
  minPrice: 0,
  maxPrice: 600000,
  sortBy: 'featured',
  inStockOnly: false,
};

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
      return stored ? JSON.parse(stored) : INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  });

  const [categories, setCategories] = useState<Category[]>(INITIAL_CATEGORIES);

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.CART);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const [wishlist, setWishlist] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.WISHLIST);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.ORDERS);
      return stored ? JSON.parse(stored) : INITIAL_ORDERS;
    } catch {
      return INITIAL_ORDERS;
    }
  });

  const [adminToken, setAdminToken] = useState<string | null>(() => {
    try {
      return localStorage.getItem(STORAGE_KEYS.ADMIN_TOKEN) || null;
    } catch {
      return null;
    }
  });

  const [isAdmin, setIsAdmin] = useState<boolean>(() => !!adminToken);
  const [adminPasswordError, setAdminPasswordError] = useState<string | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [filters, setFilters] = useState<FilterOptions>(DEFAULT_FILTERS);
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [couponError, setCouponError] = useState<string | null>(null);
  const [isLoadingData, setIsLoadingData] = useState<boolean>(false);

  // Fetch products from server database
  const refreshProducts = useCallback(async () => {
    try {
      setIsLoadingData(true);
      const res = await fetch('/api/products');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data) && data.length > 0) {
          setProducts(data);
          localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(data));
        }
      }
    } catch (err) {
      console.warn('[Store] Using cached products, server unreachable:', err);
    } finally {
      setIsLoadingData(false);
    }
  }, []);

  // Fetch categories from server database
  const refreshCategories = useCallback(async () => {
    try {
      const res = await fetch('/api/categories');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data) && data.length > 0) {
          setCategories(data);
        }
      }
    } catch (err) {
      console.warn('[Store] Using cached categories:', err);
    }
  }, []);

  // Fetch orders from server database
  const refreshOrders = useCallback(async () => {
    try {
      const res = await fetch('/api/orders');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data)) {
          setOrders(data);
          localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(data));
        }
      }
    } catch (err) {
      console.warn('[Store] Using cached orders:', err);
    }
  }, []);

  // Verify stored admin token on boot
  useEffect(() => {
    const verifyToken = async () => {
      if (!adminToken) {
        setIsAdmin(false);
        return;
      }
      try {
        const res = await fetch('/api/admin/verify', {
          headers: { Authorization: `Bearer ${adminToken}` },
        });
        const data = await res.json();
        if (data.valid) {
          setIsAdmin(true);
        } else {
          setIsAdmin(false);
          setAdminToken(null);
          localStorage.removeItem(STORAGE_KEYS.ADMIN_TOKEN);
        }
      } catch {
        // Keep current state on network hiccup
      }
    };
    verifyToken();
  }, [adminToken]);

  // Initial data load from server database
  useEffect(() => {
    refreshProducts();
    refreshCategories();
    refreshOrders();
  }, [refreshProducts, refreshCategories, refreshOrders]);

  // Save cart & wishlist to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify(cart));
    } catch (e) {
      console.error('Failed to save cart', e);
    }
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.WISHLIST, JSON.stringify(wishlist));
    } catch (e) {
      console.error('Failed to save wishlist', e);
    }
  }, [wishlist]);

  // Cart calculations
  const cartTotalCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const cartSubtotal = cart.reduce((sum, item) => {
    const effectivePrice =
      item.quantity >= 3 && item.product.wholesalePrice
        ? item.product.wholesalePrice
        : item.product.price;
    return sum + effectivePrice * item.quantity;
  }, 0);

  // Free shipping on orders >= Rs. 5,000 across Pakistan, otherwise Rs. 350
  const cartShippingFee = cartSubtotal === 0 ? 0 : cartSubtotal >= 5000 ? 0 : 350;

  let cartDiscount = 0;
  if (appliedCoupon && cartSubtotal >= appliedCoupon.minOrder) {
    if (appliedCoupon.discountType === 'percentage') {
      cartDiscount = Math.round((cartSubtotal * appliedCoupon.value) / 100);
    } else {
      cartDiscount = appliedCoupon.value;
    }
  }

  const cartFinalTotal = Math.max(0, cartSubtotal + cartShippingFee - cartDiscount);

  // Cart actions
  const addToCart = (product: Product, quantity = 1, selectedColor?: string) => {
    setCart((prev) => {
      const existingIndex = prev.findIndex((item) => item.product.id === product.id);
      if (existingIndex > -1) {
        const next = [...prev];
        const newQty = Math.min(product.stock, next[existingIndex].quantity + quantity);
        next[existingIndex] = {
          ...next[existingIndex],
          quantity: newQty,
          selectedColor: selectedColor || next[existingIndex].selectedColor,
        };
        return next;
      } else {
        return [...prev, { product, quantity: Math.min(product.stock, quantity), selectedColor }];
      }
    });
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => {
        if (item.product.id === productId) {
          const maxAllowed = item.product.stock;
          return { ...item, quantity: Math.min(maxAllowed, quantity) };
        }
        return item;
      })
    );
  };

  const clearCart = () => {
    setCart([]);
    setAppliedCoupon(null);
  };

  const applyCoupon = (code: string): boolean => {
    const cleanCode = code.trim().toUpperCase();
    const coupon = AVAILABLE_COUPONS[cleanCode];
    if (!coupon) {
      setCouponError('Invalid voucher code. Try "GADGET10" or "WELCOME500"');
      return false;
    }
    if (cartSubtotal < coupon.minOrder) {
      setCouponError(`Requires minimum order of Rs. ${coupon.minOrder.toLocaleString()}`);
      return false;
    }
    setAppliedCoupon(coupon);
    setCouponError(null);
    return true;
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    setCouponError(null);
  };

  // Wishlist actions
  const toggleWishlist = (productId: string) => {
    setWishlist((prev) =>
      prev.includes(productId) ? prev.filter((id) => id !== productId) : [...prev, productId]
    );
  };

  const isInWishlist = (productId: string) => wishlist.includes(productId);

  // Order actions (Server-backed)
  const placeOrder = async (customer: CustomerDetails, paymentMethod: PaymentMethod): Promise<Order> => {
    const payload = {
      customer,
      items: [...cart],
      subtotal: cartSubtotal,
      shippingFee: cartShippingFee,
      discount: cartDiscount,
      total: cartFinalTotal,
      paymentMethod,
    };

    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        const newOrder: Order = await res.json();
        setOrders((prev) => [newOrder, ...prev]);

        // Deduct local product stock based on server response
        setProducts((prev) =>
          prev.map((prod) => {
            const match = cart.find((c) => c.product.id === prod.id);
            if (match) {
              return { ...prod, stock: Math.max(0, prod.stock - match.quantity) };
            }
            return prod;
          })
        );

        clearCart();
        return newOrder;
      } else {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || 'Server validation failed during order placement.');
      }
    } catch (err: any) {
      console.error('[Store] Order placement error:', err);
      throw err;
    }
  };

  const retryNotification = async (
    orderId: string,
    channel: 'all' | 'email' | 'whatsapp' = 'all'
  ): Promise<{ success: boolean; error?: string }> => {
    if (!adminToken) {
      return { success: false, error: 'Admin session required' };
    }

    try {
      const res = await fetch(`/api/orders/${orderId}/retry-notification`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`,
        },
        body: JSON.stringify({ channel }),
      });

      const data = await res.json();
      if (res.ok && data.order) {
        setOrders((prev) => prev.map((o) => (o.id === orderId ? data.order : o)));
        return { success: true };
      }
      return { success: false, error: data.error || 'Retry attempt failed' };
    } catch (err: any) {
      return { success: false, error: err?.message || 'Network error while retrying notification' };
    }
  };

  const syncCatalogWithSupabase = async (): Promise<void> => {
    if (!adminToken) return;
    try {
      await fetch('/api/db/sync', {
        method: 'POST',
        headers: { Authorization: `Bearer ${adminToken}` },
      });
      await Promise.all([refreshProducts(), refreshCategories(), refreshOrders()]);
    } catch (err) {
      console.error('Failed syncing catalog with Supabase:', err);
    }
  };

  const updateOrderStatus = async (orderId: string, status: OrderStatus): Promise<void> => {
    // Optimistic UI update
    setOrders((prev) =>
      prev.map((ord) => (ord.id === orderId ? { ...ord, status } : ord))
    );

    if (adminToken) {
      try {
        await fetch(`/api/orders/${orderId}/status`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${adminToken}`,
          },
          body: JSON.stringify({ status }),
        });
      } catch (err) {
        console.error('Failed to update status on server:', err);
      }
    }
  };

  const deleteOrder = async (orderId: string): Promise<boolean> => {
    if (!adminToken) return false;
    try {
      const res = await fetch(`/api/orders/${orderId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${adminToken}` },
      });
      if (res.ok) {
        setOrders((prev) => prev.filter((ord) => ord.id !== orderId));
        return true;
      }
      return false;
    } catch (err) {
      console.error('Failed to delete order:', err);
      return false;
    }
  };

  const lookupOrder = (orderId: string) => {
    const cleanId = orderId.trim().toUpperCase();
    return orders.find(
      (ord) => ord.id.toUpperCase() === cleanId || ord.trackingNumber.toUpperCase() === cleanId
    );
  };

  // Admin Auth (Server-Verified)
  const loginAdmin = async (password: string): Promise<boolean> => {
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      });

      const data = await res.json();
      if (res.ok && data.success && data.token) {
        setAdminToken(data.token);
        setIsAdmin(true);
        setAdminPasswordError(null);
        localStorage.setItem(STORAGE_KEYS.ADMIN_TOKEN, data.token);
        return true;
      } else {
        setAdminPasswordError(data.error || 'Invalid administrator password. Please check your ADMIN_PASSWORD.');
        return false;
      }
    } catch (err) {
      console.error('[StoreContext] Login network error:', err);
      setAdminPasswordError('Unable to connect to the authentication server. Please verify your connection.');
      return false;
    }
  };

  const logoutAdmin = () => {
    if (adminToken) {
      fetch('/api/admin/logout', {
        method: 'POST',
        headers: { Authorization: `Bearer ${adminToken}` },
      }).catch(() => {});
    }
    setAdminToken(null);
    setIsAdmin(false);
    localStorage.removeItem(STORAGE_KEYS.ADMIN_TOKEN);
  };

  // Product Database Actions
  const addProduct = async (productData: Omit<Product, 'id'>): Promise<Product> => {
    try {
      const res = await fetch('/api/products', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken || ''}`,
        },
        body: JSON.stringify(productData),
      });

      if (res.ok) {
        const created: Product = await res.json();
        setProducts((prev) => [created, ...prev]);
        return created;
      }
    } catch (err) {
      console.warn('Server create failed, saving locally:', err);
    }

    const fallback: Product = {
      ...productData,
      id: `gh-prod-${Date.now()}`,
    };
    setProducts((prev) => [fallback, ...prev]);
    return fallback;
  };

  const updateProduct = async (id: string, updates: Partial<Product>): Promise<void> => {
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updates } : p))
    );

    try {
      await fetch(`/api/products/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken || ''}`,
        },
        body: JSON.stringify(updates),
      });
    } catch (err) {
      console.error('Failed to sync update to server:', err);
    }
  };

  const deleteProduct = async (id: string): Promise<void> => {
    setProducts((prev) => prev.filter((p) => p.id !== id));

    try {
      await fetch(`/api/products/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${adminToken || ''}` },
      });
    } catch (err) {
      console.error('Failed to delete on server:', err);
    }
  };

  // Image Upload handler
  const uploadImage = async (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = async () => {
        try {
          const base64 = reader.result as string;
          const res = await fetch('/api/upload', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              imageBase64: base64,
              filename: file.name,
            }),
          });
          const data = await res.json();
          if (res.ok && data.url) {
            resolve(data.url);
          } else {
            // fallback to client data URL
            resolve(base64);
          }
        } catch {
          resolve(reader.result as string);
        }
      };
      reader.onerror = () => reject(new Error('Failed reading file'));
      reader.readAsDataURL(file);
    });
  };

  const resetAllData = async (): Promise<void> => {
    try {
      await fetch('/api/db/reset', {
        method: 'POST',
        headers: { Authorization: `Bearer ${adminToken || ''}` },
      });
    } catch {
      // ignore
    }
    setProducts(INITIAL_PRODUCTS);
    setOrders(INITIAL_ORDERS);
    setCart([]);
    setWishlist([]);
    localStorage.removeItem(STORAGE_KEYS.PRODUCTS);
    localStorage.removeItem(STORAGE_KEYS.CART);
    localStorage.removeItem(STORAGE_KEYS.WISHLIST);
    localStorage.removeItem(STORAGE_KEYS.ORDERS);
  };

  const resetFilters = () => {
    setFilters(DEFAULT_FILTERS);
  };

  return (
    <StoreContext.Provider
      value={{
        products,
        categories,
        cart,
        wishlist,
        orders,
        isAdmin,
        adminPasswordError,
        selectedProduct,
        filters,
        cartTotalCount,
        cartSubtotal,
        cartShippingFee,
        cartDiscount,
        cartFinalTotal,
        appliedCoupon,
        couponError,
        isLoadingData,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        applyCoupon,
        removeCoupon,
        toggleWishlist,
        isInWishlist,
        placeOrder,
        updateOrderStatus,
        deleteOrder,
        lookupOrder,
        loginAdmin,
        logoutAdmin,
        addProduct,
        updateProduct,
        deleteProduct,
        uploadImage,
        resetAllData,
        retryNotification,
        syncCatalogWithSupabase,
        setSelectedProduct,
        setFilters,
        resetFilters,
        refreshProducts,
        refreshOrders,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
